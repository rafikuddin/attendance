# Downloads

PDF files shared by your admin: price lists, policies, forms, circulars.

## For everyone
1. Open **⬇️ Downloads** from the 👤 menu.
2. Each card shows the **title**, a short description, the file name, size and date.
3. **👁 View** opens the file in your phone's PDF viewer. **⬇ Download** asks where to save it (for example the *Downloads* folder).
4. The first time a file is fetched you see a percentage; later it opens at once (it is kept on your phone). Pull the page down to refresh the list.

## For admins
- **➕ Upload a PDF** (top of the page): choose a PDF (up to **15 MB**), type a **title** and an optional **description**, then confirm with **your own password**. A progress percentage shows while it uploads.
- **✏️ Edit** on a card: change the title or description, **untick “Shown to everyone”** to hide the file (staff no longer see it; the card shows *Hidden* for you) or **Delete** it for everyone.
- Up to **200 files**. Only real PDF files are accepted.
- You can **lock** the menu for a person: *Users → 🔐 Menu access → ⬇️ Downloads*.

## Where the files are
In the private Google Drive folder **DownloadFiles** (in 512 KB pieces; nobody can open them from Drive without the script), and the list is on the **Downloads** tab of the Google Sheet. Only signed-in app users can read them, through the script.
