# 🌐 Website Dashboard

Sign in to your reports **in a browser**, on a phone or a computer: **https://rafikuddin.github.io/attendance/dashboard/** (also the **Sign in** button at the top of the project website).

It uses the **same Employee ID and password** as the app. For most people it is **reports only**: you can look at reports and download the Excel files. A **line manager** also gets a **Leave applications** menu to approve or reject the leave of the people below them (see *The Leave applications menu* below). An **admin** (whose *Admin Panel* menu is not locked) also gets an **Admin** menu to manage the office from the browser (see *The Admin menu* below).

The page has a light look: a mint-to-cream background, a dark-green menu and banner, white cards and pastel number tiles. If your phone is set to dark, the page is deep green instead. On a computer the menu is on the left; **on a phone press the ☰ button** (top left) to open it. The sun / moon button switches between light and dark, **Refresh** loads the report again, and the last round button (an arrow leaving a door) signs you out.

## Who sees what

The server decides, exactly as in the app.

| Who | Tabs | What they see |
|---|---|---|
| **Everyone** | **My report** | Their own days |
| **Managers** | **My report**, **My team**, and **Leave applications** (under *Team*) | Their own days, everybody below them, and the leave applications of everybody below them |
| **Admins** | **My report**, **My team**, **Everyone** | The whole company (the page opens on *Everyone*) |

A person whose **My Reports** menu is locked (*Admin Panel → Users → Menu access*) gets in but sees *Reports are switched off for your account*. Locked menus apply on the website too.

## Using it

1. Open the address above (or the **Sign in** button on the project website).
2. Type your **Employee ID** and **password**, then **Sign in**. Press the eye button to check what you typed.
3. Pick **My report**, **My team** or **Everyone** in the menu, and a **period**. The page opens on **Today** (the office day, Dhaka time: the numbers, the *Today* strip and the people table for this one day; no bar chart, because one day is one bar). Other choices: *This pay period* (26th → 25th), *Last pay period* or *Choose dates…* (up to 366 days; days that have not happened yet are not counted). Press **Show** after choosing dates.
4. Read the page from the top:
   - **Today** (teams): how many are in, late, on leave, not in yet or absent, and a list of who is not in.
   - **Numbers**: tiles for present, late (inside present), leave, absent, day off, night holds, driver km, pending. A ring shows the share (the big *Present* tile also shows the on-time part in its inner ring). For a team the tiles count *person-days*: one person on one day is one day. **Press a tile** to see what is behind the number: for a team, the people (most first, with their count; *Day off* lists the days), for one person the dates with the check-in time. A tile showing 0 has nothing behind it and is not pressable. Press a name for that person's calendar; *Back* returns to the list.
   - **Day by day** (teams): one pill-shaped bar for each day on a light track: green on time, amber late, blue leave, red absent (each is also named in the legend and in the table). Point at a bar to read that day: it stays at full strength, the other days fade a little, and a dark pill above it says how many were in. The **Present** card also has a **Counted days** bar (the share of on time, late, leave, absent and not in yet) and a line over the days. **Press a bar** (or press *Enter* after choosing a day with the arrow keys, or the *Show who* button under the chart) to open the day: who was on time, late, on leave, absent or not in yet, with check-in times; *Previous day* / *Next day* move along. The *Today* strip opens today the same way. *Show these numbers as a table* gives the same numbers as text.
   - **People** (teams): a table you can sort (press a column title) and search (name, Employee ID, job or manager). Press a name to open that person's **calendar**.
   - **Calendar**: one box for each day with the letters used in the app: **In**, **Late**, **Abs**, **Off**, **Pend**, and **CL / SL / EL / PL** for the leave types. When 80 people or fewer are on the page, the check-in time is shown in the box. **Press a day** to see more under the calendar: the check-in time (and *Late* with the late reason), the **place** (address and position) with an **Open in Google Maps** link (it opens in a new tab), the face-check result (only when you look at somebody else's day) and, for a driver, the car-meter numbers. A day with a **night hold** has a small **moon** and also shows the night hold: time, hotel, area, place and its own map link. The **Night holds** chip above the calendar lists every night hold of the period. Days without a check-in (absent, day off, leave) just say so. No photo is shown on the website. You see your own days; an admin sees anybody; a line manager sees the people below them only with the *view team profiles and calendars* right (Admin Panel → Users → Menu access → Extra rights), the same rule as in the app.
5. **Excel files** at the bottom: *Attendance sheet*, *Salary sheet* and *Night holds*, for the people and the dates on the page. They are the same files as in the app.
6. **If your Attendance is switched off** (an admin unticked *Attendance* in Menu access), the site shows no *My report* for you, only a message. A manager still sees *My team* (without their own row); an admin still sees *Everyone*. The phone app is not changed. An admin can bring it back by ticking *Attendance* again.
7. When you finish, press **Sign out**. Always do this on a shared computer.

## The Leave applications menu (line managers)

A manager (anybody who has people below them) sees **Leave applications** under **Team** in the menu, with a small orange number: how many applications wait for a decision. It is the website version of the leave list in the app's Team screen. If an admin locked your **Team** menu (*Menu access*), the item is gone.

1. **Open it.** The page lists the leave applications of **everybody below you, at every level**. Three buttons at the top show the numbers: **Pending** (always all of them, whatever year they are for), **Approved** and **Rejected** (for the chosen **Year**, which appears when you look at those two). The search box finds a name, an Employee ID or a leave type.
2. **Read a card.** Name and ID, the status, the leave type, the dates (and the number of days), the reason, a small bar with that person's balance for the type (*13 of 14 days left after this one*: a pending application already counts as used) and, in amber, a warning when team mates are also off on those days. The application that starts first is on top.
3. **Approve or Reject.** Press the button, then **Yes, approve** (or **Yes, reject**) to confirm, or **Cancel**. The card moves to the other list and the numbers change at once. The person sees the result in the app. If somebody else decided the same application a moment before you, the page says *already decided* and shows the newest list; nothing is overwritten.
4. **Review.** Press **Review** (or the name) to open a window with everything: leave type, dates, when it was applied, the full reason, the balance (*Used*, *Pending*, *Left*, *Yearly days*), who else is off on those days, and for a decided one *Approved by … · date*. **Previous** and **Next** go through the list you were looking at, so you can review them one after the other. **Show the picture** brings the picture of the leave application (only when you press it; press the picture to zoom). The picture is not saved on your device and is forgotten when the window closes. Pending ones have **Approve** and **Reject** at the bottom of the window too.

The same rules as in the app: only somebody **above** the person can decide, never for yourself, and nobody outside your team. The decision is written to the *Leaves* sheet (**DecidedBy** and **DecidedOn**), like in the app. No password is asked, like in the app. Needs `Code.gs` `2026-11-21.01`.

## The Admin menu (admins only)

An admin sees an **Admin** group under the report tabs. Nobody else does: the server decides, the page only follows. If an admin's **Admin Panel** menu is locked (*Menu access*), or the website part is switched off (`WEB_ADMIN` = `off`), the group is gone.

| Page | What you can do |
|---|---|
| **Users** | Search and filter people. Press a name to open them: **Make inactive** (last working day and remarks; they are signed out everywhere and the line managers and admins get an e-mail) or **Make active again**; **Reset password** (a temporary password is shown **once**, with a *Copy* button; the person must choose their own at the next sign-in); **Reset face data**; **Menu access** and **Extra rights** (tick = allowed, untick = locked; *Save* is enabled only when something changed; you cannot lock your own Admin Panel). **Add user** makes a new account (Employee ID, name, line manager, admin or not; a temporary password is made unless you type one). |
| **Sign-up requests** | Close or open sign-up. **Approve…** (with a line manager, optional) or **Reject** a request. |
| **Holidays** | Add a holiday (date and name) or remove one. Friday is always a day off. |
| **Notices** | Post a notice for everybody (title, message, days to show) or remove one. A text message (SMS) is only possible from the app. |
| **Settings** | Night hold opening and closing hours; the *Live check* and *Meter check* safeguards (on / off); yearly leave days for each leave type. |

**Your password at every change.** A small window asks for **your own password** before each change. A wrong one is shown in that window and nothing changes; five wrong tries pause the account for 15 minutes, as in the app. After a correct password you are not asked again for **15 minutes** for the next changes (a line says so at the top; **Ask for my password again** ends it; so does *Sign out*). **Add user**, **Reset password** and **Approve** always ask. The password is sent with that one change and is not kept on the page.

**A record of every change.** Each change made from the website is added to the **WebAdminLog** sheet: when, which admin, what, about whom and what was set. It never contains a password, a temporary password or a token.

**Left to the app on purpose:** app updates, downloads, targets, products and orders, SMS, e-mail, surveys, editing profiles and photos, opening a date for manual entry, and the menu layout.

## What it cannot do

Check in, ask for leave, change a profile or a password, or anything else in the app. The server refuses every request from the website that is not a report, the leave applications of a line manager's own team, or, for an admin, one of the Admin menu actions above. A person who must **choose a new password** (a new account, or a weak password) has to open the **app first**; the website will not sign them in until they have done that.

## How long you stay signed in

- **15 minutes without use** → signed out by the page.
- **6 hours** at the most, then the server ends the sign-in. This cannot be made longer on the website.
- **Sign out** ends that one website sign-in at once. It does **not** sign out your phones, and signing in on a phone does not sign out the website.
- A password change, an admin switching the account off, or an admin revoking the account also ends the website sign-in.
- Closing the tab ends it too: the sign-in is kept in that one browser tab and nowhere else.

## For the admin: switching it on (one time)

1. **Code.gs** (`2026-11-21.01` or newer for the Leave applications menu; `2026-11-19.02` or newer when an admin's *Attendance off* must also close *My report* on the site; `2026-11-19.01` for *where and when* on a pressed day; `2026-11-18.01` for the Admin menu; `2026-11-17.01` is enough for reports only): paste it into Apps Script, then **Deploy → Manage deployments → ✏️ → Version: New version → Deploy**.
2. **worker.js**: paste it into the Cloudflare Worker (**Edit code → Deploy**). Keep the two secrets (`APPS_SCRIPT_URL`, `APP_KEY`). The new `worker.js` lets browsers on the project website (`https://rafikuddin.github.io`) talk to the Worker, and refuses browsers on any other website. The phone app is not affected. See [[Cloudflare Front Door]].
3. **Website files**: upload the new `update.zip` (it contains `docs/dashboard/` and the new `docs/index.html`), wait for **Build APK**, and let **pages build and deployment** publish the site.

If you do not use the Cloudflare Worker, or your site has another address, change `API` at the top of `docs/dashboard/dashboard.js` and the `connect-src` in the first lines of `docs/dashboard/index.html`, and add the site's address to `ALLOWED_ORIGINS` in `worker.js`.

### Switching only the Admin menu off

In Apps Script: **Project Settings → Script Properties → Add** `WEB_ADMIN` = `off`. The Admin menu goes away and the server refuses every admin action from the website at once; reports on the website and the app are not affected. Delete the property to bring it back. No new version is needed.

### Switching website sign-in off

In Apps Script: **Project Settings → Script Properties → Add** `WEB_LOGIN` = `off`. From that moment nobody can sign in on the website and the website sign-ins that are open stop working. The phones are not affected. Delete the property (or set it to anything else) to switch it on again. No new version is needed.

## Safety

- The page holds **no secret**. The only address in it is the Worker's, which is already inside every APK.
- The sign-in is a **website-only token**: it can ask for reports and, for an admin, the Admin menu actions only; it lasts at most 6 hours, is never renewed and is ended by *Sign out*. Every admin change asks for the admin's own password again and is written to the **WebAdminLog** sheet.
- The same **5 wrong passwords → 15 minute pause** rule as the app counts website tries too.
- Nothing from your reports is saved in the browser. The sign-in token lives in the tab (`sessionStorage`) and is deleted at *Sign out*. No cookies, no tracking, no outside scripts or fonts (the Inter and Lora Italic font files are part of the site).
- Everything from the server is shown as plain text, never as web-page code. The page's Content-Security-Policy allows only the website's own files and the Worker.
- The page asks search engines not to list it (`noindex`).

## If something does not work

| You see | Do this |
|---|---|
| **The server answered, but it does not let this website read the answer yet** | The Cloudflare Worker still has the old code. Paste the newest `worker.js` (Edit code → Deploy). The app is not affected. |
| **Could not reach the server** | The internet is down, or the Worker address is wrong or the Worker is switched off. Try the app too. |
| **Sign-in on the website is switched off** | An admin set `WEB_LOGIN` = `off`. Use the app, or ask the admin. |
| **Please open the SAM BOND app first and choose your own new password** | Do that in the app, then sign in here again. |
| **Too many wrong passwords** | Wait the minutes it says. An admin can lift it with *Reset password*. |
| **Your sign-in has ended** | Normal after 6 hours, a password change or an admin change. Sign in again. |
| **Reports are switched off for your account** | An admin locked *My Reports* for you. |
| **No Admin menu** | Only an admin whose *Admin Panel* menu is not locked sees it, with `Code.gs` `2026-11-18.01` or newer deployed as a **New version**. Sign out and in again after fixing it. |
| **The Admin Panel on the website is switched off** | An admin set `WEB_ADMIN` = `off`. Delete it to bring the menu back, or use the app. |
| **Your own password is wrong** | The password window wants **your own** password. Five wrong tries pause the account for 15 minutes. |
| **Only an admin can see everybody / Only a manager can download a team report** | Your account is not an admin / manager. |
| The page looks old after an update | Open it in a new tab, or reload it. |
