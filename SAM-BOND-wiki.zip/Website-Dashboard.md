# 🌐 Website Dashboard

Sign in to your reports **in a browser**, on a phone or a computer: **https://rafikuddin.github.io/attendance/dashboard/** (also the **Sign in** button at the top of the project website).

It uses the **same Employee ID and password** as the app. For most people it is **reports only**: you can look at reports and download the Excel files. An **admin** (whose *Admin Panel* menu is not locked) also gets an **Admin** menu to manage the office from the browser (see *The Admin menu* below).

The page uses a dark *glass* look with an orange accent. On a computer the menu is on the left; **on a phone press the ☰ button** (top left) to open it. The sun / moon button switches the background between dark and light, **Refresh** loads the report again, and the last round button (an arrow leaving a door) signs you out.

## Who sees what

The server decides, exactly as in the app.

| Who | Tabs | What they see |
|---|---|---|
| **Everyone** | **My report** | Their own days |
| **Managers** | **My report**, **My team** | Their own days, and everybody below them |
| **Admins** | **My report**, **My team**, **Everyone** | The whole company (the page opens on *Everyone*) |

A person whose **My Reports** menu is locked (*Admin Panel → Users → Menu access*) gets in but sees *Reports are switched off for your account*. Locked menus apply on the website too.

## Using it

1. Open the address above (or the **Sign in** button on the project website).
2. Type your **Employee ID** and **password**, then **Sign in**. Press the eye button to check what you typed.
3. Pick **My report**, **My team** or **Everyone** in the menu, and a **period**: *This pay period* (26th → 25th), *Last pay period* or *Choose dates…* (up to 366 days; days that have not happened yet are not counted). Press **Show** after choosing dates.
4. Read the page from the top:
   - **Today** (teams): how many are in, late, on leave, not in yet or absent, and a list of who is not in.
   - **Numbers**: tiles for present, late (inside present), leave, absent, day off, night holds, driver km, pending. A ring shows the share (the big *Present* tile also shows the on-time part in its inner ring). For a team the tiles count *person-days*: one person on one day is one day.
   - **Day by day** (teams): one bar for each day: green on time, amber late, blue leave, red absent (each is also named in the legend and in the table). Tap or point at a bar to read that day; with a keyboard use the arrow keys. *Show these numbers as a table* gives the same numbers as text.
   - **People** (teams): a table you can sort (press a column title) and search (name, Employee ID, job or manager). Press a name to open that person's **calendar**.
   - **Calendar**: one box for each day with the letters used in the app: **In**, **Late**, **Abs**, **Off**, **Pend**, and **CL / SL / EL / PL** for the leave types. When 80 people or fewer are on the page, the check-in time is shown in the box.
5. **Excel files** at the bottom: *Attendance sheet*, *Salary sheet* and *Night holds*, for the people and the dates on the page. They are the same files as in the app.
6. When you finish, press **Sign out**. Always do this on a shared computer.

## The Admin menu (admins only)

An admin sees an **Admin** group under the report tabs. Nobody else does: the server decides, the page only follows. If an admin's **Admin Panel** menu is locked (*Menu access*), or the website part is switched off (`WEB_ADMIN` = `off`), the group is gone.

| Page | What you can do |
|---|---|
| **Users** | Search and filter people. Press a name to open them: **Make inactive** (last working day and remarks; they are signed out everywhere and the line managers and admins get an e-mail) or **Make active again**; **Reset password** (a temporary password is shown **once**, with a *Copy* button; the person must choose their own at the next sign-in); **Reset face data**; **Menu access** and **Extra rights** (tick = allowed, untick = locked; *Save* is enabled only when something changed; you cannot lock your own Admin Panel). **Add user** makes a new account (Employee ID, name, line manager, admin or not; a temporary password is made unless you type one). |
| **Sign-up requests** | Close or open sign-up. **Approve…** (with a line manager, optional) or **Reject** a request. |
| **Holidays** | Add a holiday (date and name) or remove one. Friday is always a day off. |
| **Notices** | Post a notice for everybody (title, message, days to show) or remove one. A text message (SMS) is only possible from the app. |
| **Settings** | Night hold opening and closing hours; the *Live check* and *Meter check* safeguards (on / off); yearly leave days for each leave type. |

**Your password at every change.** A small window asks for **your own password** before each change. A wrong one is shown in that window and nothing changes; five wrong tries pause the account for 15 minutes, as in the app. After a correct password you are not asked again for **15 minutes** for the next changes (a line says so at the top; **Ask for my password again** ends it; so does *Sign out*). **Add user**, **Reset password** and **Approve** always ask. The password is sent with that one change and is not kept on the page.

**A record of every change.** Each change made from the website is added to the **WebAdminLog** sheet: when, which admin, what, about whom and what was set. It never contains a password, a temporary password or a token.

**Left to the app on purpose:** app updates, downloads, targets, products and orders, SMS, e-mail, surveys, editing profiles and photos, opening a date for manual entry, and the menu layout.

## What it cannot do

Check in, ask for leave, change a profile or a password, or anything else in the app. The server refuses every request from the website that is not a report or, for an admin, one of the Admin menu actions above. A person who must **choose a new password** (a new account, or a weak password) has to open the **app first**; the website will not sign them in until they have done that.

## How long you stay signed in

- **15 minutes without use** → signed out by the page.
- **6 hours** at the most, then the server ends the sign-in. This cannot be made longer on the website.
- **Sign out** ends that one website sign-in at once. It does **not** sign out your phones, and signing in on a phone does not sign out the website.
- A password change, an admin switching the account off, or an admin revoking the account also ends the website sign-in.
- Closing the tab ends it too: the sign-in is kept in that one browser tab and nowhere else.

## For the admin: switching it on (one time)

1. **Code.gs** (`2026-11-18.01` or newer; `2026-11-17.01` is enough for reports only): paste it into Apps Script, then **Deploy → Manage deployments → ✏️ → Version: New version → Deploy**.
2. **worker.js**: paste it into the Cloudflare Worker (**Edit code → Deploy**). Keep the two secrets (`APPS_SCRIPT_URL`, `APP_KEY`). The new `worker.js` lets browsers on the project website (`https://rafikuddin.github.io`) talk to the Worker, and refuses browsers on any other website. The phone app is not affected. See [[Cloudflare Front Door]].
3. **Website files**: upload the new `update.zip` (it contains `docs/dashboard/` and the new `docs/index.html`), wait for **Build APK**, and let **pages build and deployment** publish the site.

If you do not use the Cloudflare Worker, or your site has another address, change `API` at the top of `docs/dashboard/dashboard.js` and the `connect-src` in the first lines of `docs/dashboard/index.html`, and add the site's address to `ALLOWED_ORIGINS` in `worker.js`.

### Switching only the Admin menu off

In Apps Script: **Project Settings → Script Properties → Add** `WEB_ADMIN` = `off`. The Admin menu goes away and the server refuses every admin action from the website at once; reports on the website and the app are not affected. Delete the property to bring it back. No new version is needed.

### Switching website sign-in off

In Apps Script: **Project Settings → Script Properties → Add** `WEB_LOGIN` = `off`. From that moment nobody can sign in on the website and the website sign-ins that are open stop working. The phones are not affected. Delete the property (or set it to anything else) to switch it on again. No new version is needed.

## Safety

- The page holds **no secret**. The only address in it is the Worker's, which is already inside every APK.
- The sign-in is a **website-only token**: it can ask for reports and, for an admin, the Admin menu actions only; it lasts at most 6 hours, is never renewed and is ended by *Sign out*. Every admin change asks for the admin's own password again and is written to the **WebAdminLog** sheet.
- The same **5 wrong passwords → 15 minute pause** rule as the app counts website tries too.
- Nothing from your reports is saved in the browser. The sign-in token lives in the tab (`sessionStorage`) and is deleted at *Sign out*. No cookies, no tracking, no outside scripts or fonts (the Inter font files are part of the site).
- Everything from the server is shown as plain text, never as web-page code. The page's Content-Security-Policy allows only the website's own files and the Worker.
- The page asks search engines not to list it (`noindex`).

## If something does not work

| You see | Do this |
|---|---|
| **The server answered, but it does not let this website read the answer yet** | The Cloudflare Worker still has the old code. Paste the newest `worker.js` (Edit code → Deploy). The app is not affected. |
| **Could not reach the server** | The internet is down, or the Worker address is wrong or the Worker is switched off. Try the app too. |
| **Sign-in on the website is switched off** | An admin set `WEB_LOGIN` = `off`. Use the app, or ask the admin. |
| **Please open the SAM BOND app first and choose your own new password** | Do that in the app, then sign in here again. |
| **Too many wrong passwords** | Wait the minutes it says. An admin can lift it with *Reset password*. |
| **Your sign-in has ended** | Normal after 6 hours, a password change or an admin change. Sign in again. |
| **Reports are switched off for your account** | An admin locked *My Reports* for you. |
| **No Admin menu** | Only an admin whose *Admin Panel* menu is not locked sees it, with `Code.gs` `2026-11-18.01` or newer deployed as a **New version**. Sign out and in again after fixing it. |
| **The Admin Panel on the website is switched off** | An admin set `WEB_ADMIN` = `off`. Delete it to bring the menu back, or use the app. |
| **Your own password is wrong** | The password window wants **your own** password. Five wrong tries pause the account for 15 minutes. |
| **Only an admin can see everybody / Only a manager can download a team report** | Your account is not an admin / manager. |
| The page looks old after an update | Open it in a new tab, or reload it. |
