# 🌐 Website Dashboard

Sign in to your reports **in a browser**, on a phone or a computer: **https://rafikuddin.github.io/attendance/dashboard/** (also the **Sign in** button at the top of the project website).

It uses the **same Employee ID and password** as the app. It is **read only**: you can look at reports and download the Excel files, nothing else.

The page uses a dark *glass* look with an orange accent. On a computer the menu is on the left; **on a phone press the ☰ button** (top left) to open it. The sun / moon button switches the background between dark and light, **Refresh** loads the report again, and the last round button (an arrow leaving a door) signs you out.

## Who sees what

The server decides, exactly as in the app.

| Who | Tabs | What they see |
|---|---|---|
| **Everyone** | **My report** | Their own days |
| **Managers** | **My report**, **My team** | Their own days, and everybody below them |
| **Admins** | **My report**, **My team**, **Everyone** | The whole company (the page opens on *Everyone*) |

A person whose **My Reports** menu is locked (*Admin Panel → Users → Menu access*) gets in but sees *Reports are switched off for your account*. Locked menus apply on the website too.

## Using it

1. Open the address above (or the **Sign in** button on the project website).
2. Type your **Employee ID** and **password**, then **Sign in**. Press the eye button to check what you typed.
3. Pick **My report**, **My team** or **Everyone** in the menu, and a **period**: *This pay period* (26th → 25th), *Last pay period* or *Choose dates…* (up to 366 days; days that have not happened yet are not counted). Press **Show** after choosing dates.
4. Read the page from the top:
   - **Today** (teams): how many are in, late, on leave, not in yet or absent, and a list of who is not in.
   - **Numbers**: tiles for present, late (inside present), leave, absent, day off, night holds, driver km, pending. A ring shows the share (the big *Present* tile also shows the on-time part in its inner ring). For a team the tiles count *person-days*: one person on one day is one day.
   - **Day by day** (teams): one bar for each day: green on time, amber late, blue leave, red absent (each is also named in the legend and in the table). Tap or point at a bar to read that day; with a keyboard use the arrow keys. *Show these numbers as a table* gives the same numbers as text.
   - **People** (teams): a table you can sort (press a column title) and search (name, Employee ID, job or manager). Press a name to open that person's **calendar**.
   - **Calendar**: one box for each day with the letters used in the app: **In**, **Late**, **Abs**, **Off**, **Pend**, and **CL / SL / EL / PL** for the leave types. When 80 people or fewer are on the page, the check-in time is shown in the box.
5. **Excel files** at the bottom: *Attendance sheet*, *Salary sheet* and *Night holds*, for the people and the dates on the page. They are the same files as in the app.
6. When you finish, press **Sign out**. Always do this on a shared computer.

## What it cannot do

Check in, ask for leave, change a profile or a password, post notices, or anything in the Admin Panel. The server refuses every other request from the website, even for an admin. A person who must **choose a new password** (a new account, or a weak password) has to open the **app first**; the website will not sign them in until they have done that.

## How long you stay signed in

- **15 minutes without use** → signed out by the page.
- **6 hours** at the most, then the server ends the sign-in. This cannot be made longer on the website.
- **Sign out** ends that one website sign-in at once. It does **not** sign out your phones, and signing in on a phone does not sign out the website.
- A password change, an admin switching the account off, or an admin revoking the account also ends the website sign-in.
- Closing the tab ends it too: the sign-in is kept in that one browser tab and nowhere else.

## For the admin: switching it on (one time)

1. **Code.gs** (`2026-11-17.01` or newer): paste it into Apps Script, then **Deploy → Manage deployments → ✏️ → Version: New version → Deploy**.
2. **worker.js**: paste it into the Cloudflare Worker (**Edit code → Deploy**). Keep the two secrets (`APPS_SCRIPT_URL`, `APP_KEY`). The new `worker.js` lets browsers on the project website (`https://rafikuddin.github.io`) talk to the Worker, and refuses browsers on any other website. The phone app is not affected. See [[Cloudflare Front Door]].
3. **Website files**: upload the new `update.zip` (it contains `docs/dashboard/` and the new `docs/index.html`), wait for **Build APK**, and let **pages build and deployment** publish the site.

If you do not use the Cloudflare Worker, or your site has another address, change `API` at the top of `docs/dashboard/dashboard.js` and the `connect-src` in the first lines of `docs/dashboard/index.html`, and add the site's address to `ALLOWED_ORIGINS` in `worker.js`.

### Switching website sign-in off

In Apps Script: **Project Settings → Script Properties → Add** `WEB_LOGIN` = `off`. From that moment nobody can sign in on the website and the website sign-ins that are open stop working. The phones are not affected. Delete the property (or set it to anything else) to switch it on again. No new version is needed.

## Safety

- The page holds **no secret**. The only address in it is the Worker's, which is already inside every APK.
- The sign-in is a **website-only token**: it can only ask for reports, lasts at most 6 hours, is never renewed and is ended by *Sign out*.
- The same **5 wrong passwords → 15 minute pause** rule as the app counts website tries too.
- Nothing from your reports is saved in the browser. The sign-in token lives in the tab (`sessionStorage`) and is deleted at *Sign out*. No cookies, no tracking, no outside scripts or fonts (the Inter font files are part of the site).
- Everything from the server is shown as plain text, never as web-page code. The page's Content-Security-Policy allows only the website's own files and the Worker.
- The page asks search engines not to list it (`noindex`).

## If something does not work

| You see | Do this |
|---|---|
| **The server answered, but it does not let this website read the answer yet** | The Cloudflare Worker still has the old code. Paste the newest `worker.js` (Edit code → Deploy). The app is not affected. |
| **Could not reach the server** | The internet is down, or the Worker address is wrong or the Worker is switched off. Try the app too. |
| **Sign-in on the website is switched off** | An admin set `WEB_LOGIN` = `off`. Use the app, or ask the admin. |
| **Please open the SAM BOND app first and choose your own new password** | Do that in the app, then sign in here again. |
| **Too many wrong passwords** | Wait the minutes it says. An admin can lift it with *Reset password*. |
| **Your sign-in has ended** | Normal after 6 hours, a password change or an admin change. Sign in again. |
| **Reports are switched off for your account** | An admin locked *My Reports* for you. |
| **Only an admin can see everybody / Only a manager can download a team report** | Your account is not an admin / manager. |
| The page looks old after an update | Open it in a new tab, or reload it. |
