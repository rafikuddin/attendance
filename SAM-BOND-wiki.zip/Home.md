# 📋 SAM BOND Attendance — Wiki

Welcome! This wiki explains **how to use, run and maintain** the SAM BOND attendance app.

**What it is:** an Android app where staff check in with a **selfie + live GPS**, ask for **leave**, and report **Night Hold** (overnight stays). Managers approve leave and watch their team. Admins manage people, holidays, reports and app updates. Everything is stored in a **Google Sheet** — there is no server to run — and the APK is built automatically by **GitHub Actions**.

> **At a glance** · Android 7.0+ · Pay period **26th → 25th** · Timezone **Asia/Dhaka** · Late from **9:10 AM** · Absent after **6:00 PM** · Friday = weekly off

---

## 🧭 Find your page

| I am… | Start here |
|---|---|
| 👤 **A staff member** | [[Getting Started]] → [[Attendance]] → [[Leave]] → [[Night Hold]] → [[Orders]] |
| 👥 **A manager** | [[Manager Guide]] |
| 🛡 **An admin** | [[Admin Guide]] → [[Reports and Excel]] → [[Updating the App]] |
| 🧰 **Setting the project up** | [[Setup Guide]] → [[Configuration]] |
| 🆘 **Something is not working** | [[Troubleshooting]] · [[FAQ]] |
| 🔒 **Curious about safety** | [[Security]] · [[Cloudflare Front Door]] |
| 🧩 **A developer** | [[Architecture]] |

---

## ✨ What the app does

| | |
|---|---|
| 📸 **Selfie attendance** | Front-camera selfie + live GPS + a server-side time stamp (changing the phone clock does nothing) |
| ⏰ **Late detection** | 10-minute grace; from 9:10 AM it is *Late Present* |
| 🌴 **Leave** | Casual · Sick · Earn · Paternity, with a signed application photo and yearly balances |
| 🌙 **Night Hold** | Overnight stay report with GPS, district → thana and hotel name |
| 👥 **Team view** | Unlimited manager levels, approvals for everyone below you |
| 🔔 **Reminders** | Phone notifications for people who have not marked attendance |
| 📱 **SMS** | Send a notice or message as a text to staff phones through SimGate (a spare Android phone does the sending) |
| 🎯 **Target vs Collection** | Admin uploads the Target and Sale Collection Excel files; staff see their own numbers, managers their team |
| 🛒 **Orders** | Order for your own customers with trade-offer free items: manager → admin → accounts → delivery, invoice and challan PDFs, returns |
| ⬇️ **Downloads** | PDF files (price lists, policies, forms) uploaded by the admin; everyone can view and save them |
| 📋 **Surveys** | Admin builds a survey (nine question kinds, picture attachments); everyone answers once; admin sees results and downloads Excel |
| 📊 **Excel reports** | Attendance and Night Hold summaries with day-by-day details |
| 📲 **In-app updates** | Admin publishes a new APK; everyone updates in two taps |

---

## 🗺 How the pieces fit

```
 📱 Android app  ──HTTPS──▶  Google Apps Script (Code.gs)  ──▶  Google Sheet  +  Drive (photos, APK)
        ▲                                                              
        └──────────  APK built by GitHub Actions (signed release)  ────┘
```

New to the project? Read [[Setup Guide]] first. Already running? Use the pages on the left (the sidebar) to jump around.
