# 🌙 Night Hold

Use **Night Hold** when you are **staying away overnight** (for example in a hotel on a field trip).

## Submit a night hold

1. Open **Night Hold** (bottom bar). The screen shows the open hours, for example *"Open every night from 9:00 PM to 6:00 AM"*.
2. Wait for **📍 Location locked**.
3. Choose your **District** (all 64 districts, searchable), then your **Thana**.
4. Type the **real hotel name** (at least 3 characters, with letters).
5. Tap **Submit Night Hold**.

Every field and your live location are required. The server checks all of it again.

## Rules

| Rule | Detail |
|---|---|
| ⏰ **Hours** | Only during the night-hold hours. Default **9:00 PM → 6:00 AM**. An admin can change them in *Admin Panel → 📝 Entry*, and every phone shows the new hours automatically |
| 🌙 **Outside the hours** | The screen shows a *closed* notice and the server refuses a submission |
| 1️⃣ **One per night** | A night is named by the date its **evening started**, so a 2:00 AM submission counts for the night before |
| 📍 **Live GPS** | Required; fake/mock locations are refused |
| ❌ **No fake data** | Empty or meaningless hotel names are refused |

The Night Hold hours can run through midnight (8 PM → 5 AM) or sit inside one day. If the closing hour is earlier than the opening hour, the window crosses midnight.

## Missed a night?

An admin can open a **past night** for you (or your team) with **manual entry** — see [[Admin Guide]]. You will see **📝 Manual entry** in the 👤 menu. Manual entries are labelled **Manual** in reports.

## Where to see your night holds

- **Top of the Night Hold screen** — a summary of the **current cycle (26th to 25th)**: how many nights you submitted and the last one. Tap **‹** for the previous cycle and **›** to come back (you cannot go past the current cycle).
- **Below the form** — the details of each of those nights: date and time, hotel, thana and district. Tap a night to open its location in Maps. Both update as soon as you submit.
- **Home** — this month's night holds.
- **Calendar** — 🌙 days; tap a date for the hotel and location. See [[Profile and Calendar]].

Related: [[Attendance]] · [[Reports and Excel]]
