# ❓ FAQ

### Can I change the phone's clock to look on time?
No. The date and time are stamped by Google's server, not the phone.

### Why am I marked Late at 9:10 but not at 9:09?
There is a 10-minute grace period after 9:00. 9:09 is on time; **9:10 or later is Late Present**.

### When do I become Absent?
If nothing is marked by **6:00 PM**. Friday and holidays are never absent. Approved leave is never absent.

### I forgot to check in yesterday. What now?
Ask an admin to open a **manual entry** for that date. You then fill the normal screen once. See [[Admin Guide]].

### Why does the night hold say "closed"?
It is open only during the hours the admin set (default 9 PM → 6 AM). A 2 AM submission counts for the night before.

### Do I get a notification when the app is closed?
Reminders appear in the notification bar even when the app is closed, but they are checked by the phone about every 30 minutes — not instant push. Notice pop-ups only show when you open the app.

### Does the leave balance reset?
Yes, each **calendar year**. Pending and Approved requests both count.

### Who can see my selfie?
You and the supervisors above you in the Manager chain. Admins see *when and where*, but not your selfie unless they are above you.

### Can an admin see my password?
No. Passwords are stored only as salted hashes. An admin can **reset** it to a temporary one, which you must change at your next sign-in.

### I changed phones. Do I lose anything?
No. Everything is in the Google Sheet. Install the app and sign in.

### Do I have to update the app?
When an admin publishes a new version, **⬆️ Update available** appears on Home. Two taps — your data is not affected.

### Why can't I install the new APK over the old one?
The old one was signed with a different key. Uninstall it once and install the new one; after that updates install normally. See [[Troubleshooting]].

### Is there an iPhone version?
No. Android 7.0+ only.

### Who can add holidays or change the night-hold hours?
Admins only, in the Admin Panel.

Related: [[Troubleshooting]] · [[Security]]
