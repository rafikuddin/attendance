# 📱 SMS Notifications

Send a **text message (SMS) to people's phone numbers** — a notice, or any message — using [SimGate](https://simgate.app). Your own spare **Android phone with a SIM** does the sending.

> [!NOTE]
> This is **real SMS** (it reaches the phone even when the app is closed). It uses the SIM's own SMS plan. The app keeps a **monthly safety limit** (default 200, you can change it) so a mistake cannot send hundreds of texts.

## How it works

```
Admin / manager  →  Apps Script (Code.gs)  →  api.simgate.app  →  your spare Android phone  →  SMS to staff
```

- The **API key and the Device ID are stored only on the server** (Script Properties). They are never in the app, the Sheet or GitHub, and the app only shows `••••` and the last 4 characters.
- A person's number is the **Official phone** in *My Profile* (or the **Personal phone** if there is no Official one). Bangladesh numbers like `01712345678` are changed to `+8801712345678` automatically.
- **One text per number**, even if two people share it. The sender never texts themselves.
- Every send is counted against a **monthly limit** (default 200). A send that would go over the limit is **refused**, not half-sent.
- Each send is written to the **SmsLog** tab in the Sheet: time, who sent it, to whom (e.g. *Everyone*), how many sent / failed / had no phone, and the message. Phone numbers and the key are never logged.

## One-time setup (admin)

1. **Spare phone:** install the **SimGate** app on an Android phone with a SIM, register the device, and keep it switched on with internet.
2. In the SimGate app **copy the API key** and the **Device ID**.
3. Paste the newest `Code.gs` into Apps Script and **Deploy → Manage deployments → ✏️ → New version → Deploy**.
4. In the Apps Script editor choose the function **`authorizeSms`** and press **Run**. Approve the permission ("connect to an external service"). The log should say *SimGate reachable… permission is granted*.
5. In the app: **👤 menu → Admin Panel → 📱 SMS**. Paste the **API key**, the **Device ID** and (optional) the monthly limit, type **your own password**, tap **Save SMS settings**.
6. Make sure your own **Official phone** is in *My Profile*, then tap **✉️ Send a test text to my phone**.

## Sending

| Where | What |
|---|---|
| **Admin Panel → 📢 Notices** | Tick **📱 Also send as an SMS to everyone's phone**. The app shows how many people will get it, how many have no number and how many messages are left, then you confirm. The notice is posted either way. |
| **Notices → ✍️ Post a notice** (managers) | Tick **📱 Also send as an SMS to my team** — goes to your team only, never to people outside it. |
| **Admin Panel → 📱 SMS → Send a text message** | Any message (up to 300 characters) to **everyone**, **a whole team** or **selected people**. Needs **your own password**. |

The text of a notice SMS is: `SAM BOND notice: <title>` + the message + `- <poster's name>` (cut to 300 characters).

## Good to know

- If SMS is **not set up**, the notice is still posted and the app says the SMS was not sent.
- A person with **no phone number** is skipped and counted as *no phone*; ask them to fill *My Profile*.
- The app reads "accepted by SimGate". Delivery then depends on the spare phone being on, online and having SMS credit.
- Changing the key or Device ID later: **📱 SMS** tab, enter the new values and your password. Leave the key empty to keep the old one.

Related: [[Admin Guide]] · [[Notices and Reminders]] · [[Troubleshooting]] · [[Security]]
