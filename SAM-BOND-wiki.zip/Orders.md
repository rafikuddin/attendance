# Orders

Take an order for one of your customers, follow it until it is delivered, and send back products that should not stay with the customer.

## For a sales person
1. Open **🛒 Orders** (👤 menu). **My orders** lists your orders with their latest status.
2. Tap **➕ New order**. Choose the **customer** (only customers the admin gave to you), tap **➕ Add a product**, pick it and type the quantity. Tap a quantity to change it, ✕ to remove a product.
3. The **price, free items (trade offers) and total** appear at once. They always come from the server, so they cannot be changed on the phone.
4. Add a note if you like and press **📨 Send the order**.

## The steps an order goes through
| Step | Status | Who |
|---|---|---|
| 1 | **Pending Manager** | your line manager (or an admin) approves or rejects. If you have no active manager the order goes straight to step 2 |
| 2 | **Pending Admin** | an admin gives the final approval |
| 3 | **Pending Accounts** | the **Accounts** person types the **received amount** (0 up to the order total) |
| 4 | **With Delivery** → **Ready to Ship** → **Shipped** → **Delivered** | the **Delivery** person moves it one step at a time |

- Nobody can approve their own order.
- A rejection needs a reason; you see it in the order history.
- You can **🚫 Cancel** an order until the admin has approved it.
- Open an order to see the lines, free items, received and due amounts and the **history** of every step.

## 🧾 Invoice and 🚚 Challan
From *Pending Accounts* onwards every order has an invoice (prices, total, received, due) and a challan (quantities and a signature row, no prices). Tap the button: the PDF opens on your phone; save or share it from your PDF viewer.

## ↩ Returns
Open a **Delivered** order and tap **↩ Return products**. Type how many of each product you send back (free items can be returned too, up to what was delivered, minus earlier returns) and the reason. The **admin or delivery person** approves or rejects it, then marks it **Received**. The *Returns* tab shows your returns and their status; people with the right also see the ones waiting for them.

## Admin setup (Orders → ⚙️ Setup)
- **📦 Products** — add or edit (SKU, name, unit, price, active) or **upload an Excel** with the columns *SKU, Name, Price* and optionally *Unit*. The same SKU updates the product.
- **👥 Customers** — add or edit or **upload an Excel** with *Code, Name, Address, Phone* and *Username* (the sales person). A customer without a person cannot be ordered for.
- **🎁 Offers** — *buy N → M free*. Choose the product, optionally one customer (empty = everybody), optionally a different free product, and optional dates. A customer offer beats an all-customer offer; if several levels exist the highest one reached is used (buy 20 → 2 free also gives 4 free for 40).
- **📋 All orders** (tab in Orders) — every order, filter by status, search by order number, customer or person.
- **Who is Accounts / Delivery?** *Users → 🔐 Menu access → EXTRA RIGHTS → 💰 Accounts / 🚚 Delivery.*
- Changes to products, customers and offers need your admin password.
- Optional: Script Properties `COMPANY_NAME` and `COMPANY_ADDRESS` print at the top of invoices and challans.

## Data
Sheets **Products, Customers, Offers, Orders, OrderLines, OrderLog, Returns** are created by the script the first time they are needed. Numbers: ORD-000001, INV-000001, CH-000001, RET-000001, OF-0001.
