# Surveys

Ask your team questions and collect the answers in one place.

## For everyone
1. Open **Surveys** (Home tile, or 👤 menu → 📋 Surveys). A badge shows how many are waiting.
2. Tap a survey, answer, and press **Submit**. You can answer **once**; afterwards you can open it to see what you sent.
3. Required questions are marked with *. For an **📎 attachment** question tap *Take a photo* or *Choose a picture*.
4. A 🔒 **Anonymous** survey does not save your name with your answers.
5. A survey with a ⏰ deadline closes after that day; a closed survey can be read but not answered.

## Question kinds
Short answer · Paragraph · Single choice · Multiple choice · Dropdown · Rating (1–5 or 1–10) · Yes / No · Number · Date · Attachment (picture).

## For admins and survey managers
Surveys → **⚙️ Manage surveys**.

**Who can manage surveys?** Admins always. To let somebody else (for example an HR colleague) do it, open **Admin Panel → Users → the person → 🔐 Menu access** and tick **📋 Can create & manage surveys** under *Extra rights*. They then see ⚙️ Manage surveys inside Surveys and can create, edit, close, delete and read the results of every survey. It gives no other admin power (no Users, no uploads). Untick it to take the right away. It can also be set for several people at once.

| Action | What it does |
|---|---|
| ➕ New survey | Title, explanation, optional picture, deadline, audience (everyone / chosen people), Anonymous, questions. Surveys for everyone can also post a notice. |
| 📊 Results | Totals and percent bars, averages, written answers, attachment thumbnails (tap to enlarge), who has not answered, **📥 Download Excel** (Summary + Responses; attachments as links). |
| ✏️ Edit | Change title, deadline, audience, picture. Once someone answered, questions and the Anonymous choice are locked. |
| ⏸ Close / ▶️ Open again | Stops or restarts answers. |
| 🗑 Delete | Needs your password. Removes the survey, all answers and attachment pictures. |

### Limits
30 questions per survey, 15 choices per question, 5 attachment questions, 200 surveys. Pictures only (JPEG, shrunk on the phone); PDFs and documents are not supported.

### Where it is stored
Google Sheet tabs **Surveys** and **SurveyResponses**. Attachment pictures are in the private Drive folder used for selfies and are shown only to the admin and to the person who sent them. In anonymous surveys the respondent is stored as a one-way code, so even the sheet shows no name.

### Menu access
Admins can lock **Surveys** for a person like any other menu (Users → 🔐 Menu access).
