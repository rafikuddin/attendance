# ⚙️ Configuration

Most settings are constants at the top of **`Code.gs`**. Some are changed from the **Admin Panel**.

> [!IMPORTANT]
> After **any** change to `Code.gs`: **Deploy → Manage deployments → ✏️ → Version: New version → Deploy.** Saving alone is not enough.

## Working time

| Setting | Constant | Default |
|---|---|---|
| Timezone | `TZ` | `Asia/Dhaka` |
| Late cutoff | `LATE_HOUR`, `LATE_GRACE_MINUTES` | `9` and `10` (late from 9:10 AM) |
| Absent cutoff | `ABSENT_AFTER_HOUR` | `18` (6:00 PM) |
| Pay period | `PERIOD_START_DAY` / `PERIOD_END_DAY` | 26 → 25 |
| Weekly off | `isFridayDate` | Friday |
| Allowed check-in area | `GEO_CHECK`, `GEO_BOX` | Bangladesh + margin |

> The late/absent hours and pay period are **also used by the app screens** (Home and Calendar). Keep them in sync if you change them.

## Leave

| Setting | Constant | Default |
|---|---|---|
| Yearly quotas | `QUOTA` | Casual 10, Sick 14, Earn 17, Paternity 3 |
| Shortest reason | `MIN_REASON_LENGTH` | 3 characters |

## Night hold

| Setting | Where | Default |
|---|---|---|
| **Night-hold hours** | **Admin Panel → 📝 Entry** | 9 PM → 6 AM |
| Starting values | `NIGHT_OPEN_HOUR`, `NIGHT_CLOSE_HOUR` | `21` and `6` |
| Districts & thanas | `app/src/main/assets/bd_locations.txt` | 64 districts |

## Sign-in and passwords

| Setting | Constant | Default |
|---|---|---|
| Short sign-in (box unticked) | `SHORT_SESSION_HOURS` | 12 hours |
| Token lifetime | `TOKEN_DAYS` | 30 days |
| Minimum password length | `MIN_PASSWORD_LENGTH` | 8 |
| Wrong-password limit | `MAX_FAILED_LOGINS` | 5 |
| Lockout | `LOCKOUT_MINUTES` | 15 |

## Profiles

| Setting | Constant | Default |
|---|---|---|
| Laptop field for managers only (`false` = everyone) | `LAPTOP_FOR_MANAGERS_ONLY` | `true` |
| Emergency-contact relations ("Other" is added by the app) | `RELATIONS` | Wife, Son, Brother, Mother, Father, Daughter |

## Reminders and notices

| Setting | Constant | Default |
|---|---|---|
| Reminders on/off for everyone | `REMINDERS_ON` | on |
| First reminder time | `REMIND_FROM_HOUR`, `REMIND_FROM_MINUTE` | 8:30 AM (stops at `ABSENT_AFTER_HOUR`) |
| Notice length of stay | `NOTICE_DEFAULT_DAYS`, `NOTICE_MAX_DAYS` | 7 days, 90 days |
| E-mail reports: people per request / most people in one go | `EMAIL_BATCH`, `EMAIL_MAX_RECIPIENTS` | 10, 300 |
| SMS: starting monthly limit (change it in **Admin Panel → 📱 SMS**) | `SMS_DEFAULT_MONTHLY_LIMIT` | 200 |
| SMS: longest message / most people per send | `SMS_MAX_LENGTH`, `SMS_MAX_RECIPIENTS` | 300 characters, 200 people |

## App updates and reports

| Setting | Constant | Default |
|---|---|---|
| Biggest in-app update | `UPDATE_MAX_BYTES` | 40 MB |
| Longest Excel report | `REPORT_MAX_DAYS` | 366 days |
| Biggest Excel report | `REPORT_MAX_CELLS` | 40,000 person-days |

## Server URL

| Setting | Where |
|---|---|
| Script URL | `Api.kt` → `Config.SCRIPT_URL` (the Cloudflare Worker address, or the Apps Script `/exec` address if you do not use the worker, see [[Cloudflare Front Door]]) |
| Sheet ID | Script Property `SHEET_ID` (preferred), or `Code.gs` → `SHEET_ID` |

## Script Properties (Apps Script → Project Settings)

Never put these values in the app, GitHub, the README or this wiki.

| Property | Purpose |
|---|---|
| `SHEET_ID` | The Sheet's ID, kept out of the code. After setting it, blank the constant at the top of `Code.gs` |
| `MAKE_ADMIN_USER` | The Employee ID that `makeAdmin()` turns into an admin. Needed once |
| `APP_KEY` | The secret key shared with the Cloudflare Worker. When set, the script refuses any request without it. Set it **last** |
| `RELEASE_CERT_SHA256` | The SHA-256 fingerprint of your release signing certificate. When set, publishing an APK signed with another key is refused. The Executions log shows the fingerprint of the first APK you publish |
| `TOKEN_SECRET` | Created by the script itself. Never change it by hand |
| `NIGHT_OPEN`, `NIGHT_CLOSE`, `LEAVE_QUOTA`, `MENU_LAYOUT`, `APP_UPDATE` | Written by the Admin Panel. Do not edit by hand |

## Security constants (`Code.gs`)

| Setting | Constant | Default |
|---|---|---|
| Password hashing rounds | `PBKDF2_ITERATIONS` | 150,000 |
| Admin password proof lifetime | `ELEV_MINUTES` | 15 minutes |
| Reset codes for the whole app per hour | `RESET_MAX_REQUESTS_ALL_PER_HOUR` | 20 |
| Lock-out e-mails per hour | `LOCKOUT_MAILS_PER_HOUR` | 10 |

Related: [[Setup Guide]] · [[Admin Guide]]
