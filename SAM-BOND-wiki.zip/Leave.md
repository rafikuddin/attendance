# 🌴 Leave

## Apply for leave

1. Open **Leave**.
2. Choose the **type**: Casual, Sick, Earn or Paternity.
3. Pick the **from** and **to** dates. Days are counted for you.
4. Write a **reason** (at least 3 characters).
5. Attach a **picture of your signed leave application**: 📷 *Take photo* or 🖼 *Choose picture*.
   - The app then **checks the picture** (*🔍 Checking that this is a leave application…*). **Only a leave application is accepted**; any other picture is refused. The **Apply for Leave** button appears only after the picture passes (*✅ Leave application checked*).
   - Tips for a clean pass: photograph the **whole page**, flat, in **good light** and in focus, with the text readable; write or type in **English** (the check cannot read Bangla yet). Handwriting is fine if it is neat and dark.
6. Tap **Submit**.

> [!IMPORTANT]
> **Both the reason and the picture are required.** The server refuses a request without them, not just the app.

The picture is shrunk on your phone and stored privately. You, your manager and every supervisor above you can open it from the request (**📎 View leave application**).

## Yearly balance

| Type | Days per year (standard) |
|---|---|
| Casual | 10 |
| Sick | 14 |
| Earn | 17 |
| Paternity | 3 |

Each type shows *left of total · used*. The yearly days are **10 · 14 · 17 · 3** unless an admin changed them in *Admin Panel → 🌴 Leave*. Balances **reset each calendar year** and count **Approved + Pending** requests. The app has no gender field, so every employee has the Paternity balance.

## Status

| Status | Meaning |
|---|---|
| 🟡 **Pending** | Waiting for a manager above you |
| 🟢 **Approved** | Counts as leave on the calendar; you cannot check in on those days |
| 🔴 **Rejected** | Does not count |

**Pending applications are always listed first**, then the decided ones. Every decided application shows **✅ Approved by <name> · date and time** (or ❌ Rejected by …), so you can see who decided.

Nobody can approve their own leave. A supervisor can decide leave for **everyone below them** — see [[Manager Guide]].

## Tips

- *Take photo* does nothing? Allow the **Camera** permission (Settings → Apps), or use *Choose picture*.
- Approved leave days never become Absent.

Related: [[Attendance]] · [[Profile and Calendar]]
