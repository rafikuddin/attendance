# 📲 Updating the App

There are **three different things** to update. Do the ones that changed.

| What changed | What to do |
|---|---|
| 📱 **The app** (Kotlin, screens) | Upload `update.zip` → **Build APK** → publish the APK (below) |
| 🧠 **`Code.gs`** (server) | Paste into Apps Script → **New version** |
| ⚙️ **A workflow** (`.github/workflows/*.yml`) | Edit directly on GitHub |

---

## A. Update the project from a phone (no computer)

1. On the repo's main page: **Add file → Upload files** and upload `update.zip`.
2. The **Apply Update** workflow unpacks it into the project automatically and then **starts Build APK by itself**.
3. Wait for **Build APK** to show a green tick (about 5–10 minutes).
4. Download the new APK from the run's **`app-release`** artifact or the **Releases** page (easiest on a phone).

> [!NOTE]
> A zip cannot change files in `.github/workflows/`, and it never contains `Code.gs`.

## B. Update `Code.gs`

1. Open the Apps Script project and paste the new `Code.gs` over the old one. **Keep your own `SHEET_ID`** if you set one.
2. **Deploy → Manage deployments → ✏️ → Version: New version → Deploy.**

> [!WARNING]
> **Saving is not enough.** Without a new version, the live URL keeps running the old code.

> [!TIP]
> The app tells you whether this worked: **Admin Panel → 📲 App → 🖥 Server (Code.gs)** (and one line at the top of *Users*) shows the live `Code.gs` version, green *up to date* or an orange warning if the live script is older than the app.

## C. Publish the APK to everyone (in-app update)

1. Download the new APK to your phone from the **Releases** page.
2. In the app: **👤 menu → Admin Panel → 📲 App → Upload new version (APK)**.
3. Pick the file, add a short *What's new* note, confirm with **your password**, wait for the progress bar.
4. The box **Compulsory: people cannot use the app until they install it** is ticked by default. Everyone with an older build is then stopped on a full-screen **Update required** page (**Download and install**, **Check again**) and can use nothing else until the new build is installed. Untick it for a normal optional update: people just see **⬆️ Update available** on Home and install it in two taps.
5. Changed your mind? On the published version's card tap **Make it optional** (or **Make it compulsory**), confirming with your password.
6. A phone learns about it the next time it opens or refreshes Home. Phones that still run a build from before this feature only see the optional card, so they need to install this version once the normal way.

**Stop offering this update** withdraws it (and releases everyone from the Update required page).

### Requirements

- The APK must be signed with **the same key** as the installed app (the four signing secrets — see [[Setup Guide]]). A `…-TEMP-KEY.apk` cannot update a normally-signed app.
- The build number must be **higher** than the installed one.
- Phones with a build older than this feature must install once by hand.
- Each phone needs **Install unknown apps → allow for SAM BOND Attendance** (the app opens that screen the first time).
- Biggest APK accepted: **40 MB**. Stored in Drive in 512 KB pieces; only signed-in users can download; a newer upload deletes the older file.
- The phone checks a **SHA-256 fingerprint** before installing.

## D. A security update (admin password, e-mail alerts, worker)

When an update changes both the app and `Code.gs` for security, the order matters:

1. Upload `update.zip`, wait for **Build APK**, and publish the APK from **Admin Panel → 📲 App**.
2. Wait until the admins have updated. An admin still on the old app cannot do the six password-guarded actions until they update.
3. Paste the new `Code.gs` and deploy a **New version**.
4. In Apps Script run `securityCheck()` (a few times, hashing is slower now), and `revokeEveryone()` if you want everyone to sign in again.
5. Only when every phone is on the new app: add the Script Property `APP_KEY` (see [[Cloudflare Front Door]]).
6. Optional: set `RELEASE_CERT_SHA256` so only an APK signed with your key can be published.

## Version numbers

Every build is **`1.0.<run number>`** (for example `1.0.56`), named `SAM-BOND-Attendance-v1.0.56.apk`. The version shows on the login screen and in the 👤 menu.

Related: [[Troubleshooting]] · [[Admin Guide]]
