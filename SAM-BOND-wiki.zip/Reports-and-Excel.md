# 📊 Reports and Excel

## Who can download what

| Who | Where | What they get |
|---|---|---|
| **Everyone** | 👤 menu → **📊 My Reports** | Their **own** report |
| **Managers** | 👤 menu → **📊 My Reports → 👥 My team** | Their own **plus everyone below them** |
| **Admins** | Admin Panel → **📊 Report** | **Everyone** |
| **Salary sheet** | The **💰 Salary sheet** card on the same screens | One row per person for a pay period (same people as above) |

The server decides whose data you may have; nobody can get a report for someone outside their own line. The file layout is the same for all three.

---

The Report screen builds a real **`.xlsx`** file. Choose:

1. *(managers only)* **Whose report:** 👤 *Only me* or 👥 *My team*.
2. **Report:** tap 📍 *Attendance*, 🌙 *Night hold*, or **both** (a ✔ shows what is selected; at least one stays on). With both selected you get two files, one after the other, each with its own Save / Share.
3. **Period:** *This pay period* · *Last pay period* · *Choose dates* (up to **one year**).
4. Tap build, then **💾 Save** to your phone or **📤 Share**.

File names: `attendance_<from>_to_<to>.xlsx` and `night_hold_<from>_to_<to>.xlsx`.

> [!TIP]
> Need the numbers for salary? Use the **💰 Salary sheet** card below the form (see the end of this page): one tap, one file, one row per person.

---

## ✉️ E-mail the reports to staff (admins)

On **Admin Panel → 📊 Report**, below the download card, **✉️ E-mail reports to staff** sends every person **their own** report as an Excel attachment (never anyone else's).

1. Choose the **period** in the card above (this pay period, last pay period, or dates).
2. Tick **Attendance** and/or **Night hold**.
3. Choose **Everyone**, **a whole team**, or **selected people**, type **your own password** and tap **Check and send**.
4. The app tells you how many people will get a mail, how many have **no e-mail saved** (skipped) and how many mails are left today. Confirm with **Send**; it sends in groups of 10 and shows the progress.

**Where the address comes from:** the **Email** in each person's **My Profile**. **One-time setup:** paste the new `Code.gs` and deploy a **New version**, then in the Apps Script editor run the function **`authorizeEmail`** once and approve "send email as you". Mails are sent from the Google account that owns the script (about **100 mails a day** on a normal Gmail account, **1500** on Google Workspace; the app shows what is left). Each send is recorded on the **EmailLog** tab (time, who, period, counts; no addresses).

## 📍 Attendance report

### Sheet 1 — *Summary* (one row per person)

| Column | Meaning |
|---|---|
| User ID | Username |
| User Name | Full name |
| Period | The date range |
| Present | Days attendance was marked (includes late) |
| Late | Late days — *part of* Present |
| Leave | Approved leave days (all types together) |
| Casual Leave · Sick Leave · Earn Leave · Paternity Leave | How many of those leave days were of each type. The four add up to *Leave* |
| Absent | Working days with nothing marked |
| Day Off | Fridays and holidays |
| Pending | Today, before 6 PM |
| Total Days | Days in the period so far |

### Sheet 2 — *Daily Details* (one row per person per day)

Date · weekday · **Status** (colour-coded) · time · leave type · day-off reason (Friday / holiday name) · location · coordinates.

### How a day is classified

A day takes the **first** that applies:

1. **Present** — attendance marked (⏰ *Late Present* from 9:10 AM)
2. **Leave** — approved leave
3. **Day Off** — Friday or holiday
4. **Pending** — today, before 6:00 PM
5. **Absent**

Days that have not happened yet are **not counted**.

---

## 🌙 Night hold report

### Sheet 1 — *Night Hold Report* (the Samuda layout)

Three title lines (company name, **DSM/ZM & RSM/ASM Night Hold Report**, and the period as *from & to*, e.g. *26/8/2026 & 25/9/2026*), then a table with boxed, centred cells:

| E ID | Name | Desig | **N/H Location and Qty** (red) | Total |
|---|---|---|---|---|

* Every person has **three rows**: *Date*, *Night Hold Location*, *Night Hold Qty*, with **one column per night** (at least 8 columns, more if someone has more nights). Qty is 1 per night.
* E ID, Name, Desig and Total are merged across the person's three rows.
* **Total** = number of nights. There is no deduction column. People with no night hold in the period are left out of this sheet.
* **Location** = the thana of the night hold (district if there is no thana; the written location for a manual entry).
* **Desig** is the person's **Designation** from their profile (an admin picks it in *Admin Panel → Users → Profile*; stored in the *Profiles* tab, column N). Blank if none is set.
* Settings (Script Properties, all optional): `COMPANY_NAME`, `NIGHT_REPORT_TITLE`.
* The sheet prints landscape, one page wide.

### Sheet 2 — *Night Holds* (all records)

Every record: night date · weekday · time · district · thana · hotel · location · latitude/longitude · **Entry** (*Normal* or *Manual*). Sorted by date, then username.

---

## 💰 Salary sheet

One tap makes one Excel file for a whole **pay period** (26th to 25th), one row per person. It is on the **📊 My Reports** screen (card *💰 Salary sheet*) and on **Admin Panel → 📊 Report**. Tap **This pay period** (counted up to today) or **Last pay period**, then **💾 Save** or **📤 Share**.

**Who is in the file:** a normal person gets their own row; a manager gets themselves and everyone below them; an admin gets everybody. Somebody made inactive stays in the file when their **last working day** is inside the period (days after it are not counted); somebody who left before the period is not in it.

| Column | Meaning |
|---|---|
| **Present** | Days with an attendance (a Late day is also Present) |
| **Late (part of Present)** | Present days after the late time; drivers are never late |
| **Leave** and one column per leave type | Days of **approved** leave on days without an attendance, in total and by type |
| **Absent** | A working day with no attendance and no approved leave (today stays *Pending* until it is over) |
| **Day Off** | Fridays and the holidays set in the Admin Panel, when there is no attendance |
| **Pending** | Today, until the day is over (a driver is pending until the end of the day) |
| **Total Days** | Present + Leave + Absent + Day Off + Pending |
| **Night Holds** | Night holds with a night date inside the period (manual entries included) |
| **Driver km** | For a driver: day end km minus morning km, added up over the days where both numbers were read |

A second sheet, **How to read**, explains the columns inside the file. File name: `salary_sheet_<from>_to_<to>.xlsx`.

> [!NOTE]
> The Users sheet has no joining date, so the days before a new person's first day show as **Absent**. The *Total Days* column is not added up in the Total row.

---

## Good to know

- The sheets do **not know when someone joined**, so days before a new person's first day show as **Absent**.
- Limits: up to **366 days** and about **40,000** person-day cells per file.
- Admins see *when and where*, but not selfies.
- Files are built on the server and saved in the phone's temporary space; they are wiped on logout.

Related: [[Admin Guide]] · [[Night Hold]]
