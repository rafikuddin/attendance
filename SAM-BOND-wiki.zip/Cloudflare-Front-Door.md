# 🚪 Cloudflare Front Door

An **optional** extra layer in front of the Apps Script web app. The app calls a small **Cloudflare Worker**; the worker adds a secret key and passes the request on. When the key is switched on in Apps Script, the script refuses everything that does not come through the worker.

**What you get:** a request flood from one address is slowed down, huge requests are refused, and the long Apps Script address is no longer a usable door by itself. It is free (Cloudflare's free plan is enough) and takes about 20 minutes.

```
App ──▶ Cloudflare Worker ──(adds ?k=KEY)──▶ Apps Script (checks the key) ──▶ Sheet and Drive
```

> [!WARNING]
> The secret key must **never** be put in the app, in GitHub, in the README or in this wiki. It lives in exactly two places: the Worker's *secrets* and the Apps Script *Script Properties*.

## 1. Create the worker

1. Sign up at cloudflare.com. Open **Workers & Pages → Create application → Hello World**, name it (for example `sambond`) and **Deploy**.
2. Click **Edit code**, delete the sample, paste the whole of `worker.js`, and **Deploy** again.
3. Open the worker's address (`https://<name>.<account>.workers.dev`) in a browser. It should say **Not allowed**. That is correct: it only accepts requests from the app.

## 2. Give it two secrets

In the worker: **Settings → Variables and Secrets → Add**. Choose the type **Secret** for both:

| Name | Value |
|---|---|
| `APPS_SCRIPT_URL` | The web app address ending in `/exec` |
| `APP_KEY` | A long random string (30+ letters and numbers). Keep a copy somewhere safe |

No KV storage is needed. (The free plan allows only 1,000 KV writes a day, which a whole company would use up.)

## 3. Point the app at the worker

In `Api.kt`, `Config.SCRIPT_URL` is the worker's address instead of the `/exec` address. Build the APK and publish it from **Admin Panel → 📲 App**. Wait until everyone has the new version.

Until the key is switched on (step 4), **both** addresses work, so phones on the old version keep working.

## 4. Switch the key on

In Apps Script: **Project Settings → Script Properties → Add** `APP_KEY` with **exactly the same** string. From now on a request without the key is answered with **Not allowed.**

> [!IMPORTANT]
> Do step 4 **last**. Phones that still use the old `/exec` address stop working the moment the key is set.

**Changing your mind or something broke?** Delete the `APP_KEY` Script Property. The script accepts every request again.

## Limits

| What | Value |
|---|---|
| Requests per address per minute | 120 (an office shares one address, so this is generous) |
| Biggest request | 4,000,000 bytes (the same as `Code.gs`) |
| Methods | `POST` only |

The limit counts inside the worker's memory, so a very fast burst can slip a few extra requests through. It is a brake, not a wall.

Related: [[Security]] · [[Configuration]] · [[Setup Guide]]
