# 🧩 Architecture

For developers and maintainers.

## Tech

| Part | Technology |
|---|---|
| App | Kotlin, AppCompat, Material Components |
| Camera | CameraX |
| Location | Google Play Services (fused location) via `LiveLocation.kt` |
| Background | WorkManager (reminders, about every 30 minutes) |
| Backend | Google Apps Script web app (`Code.gs`) |
| Data | Google Sheets; Google Drive for selfies, leave pictures and the published APK |
| Build | GitHub Actions → signed release APK |

## Request flow

```
App ──POST {action, token, …}──▶ doPost router (Code.gs)
        │                          ├─ authToken: signed token, lockout, mustChange gate
        │                          ├─ role check (Role column = admin)
        │                          └─ action handler → Sheet / Drive
        ◀──────── JSON {ok, …} ────┘
```

- **Auth:** salted PBKDF2 hashes in the Users sheet; the app keeps only a signed token, encrypted with the Android Keystore.
- **A `mustChange` account** may call only `changePassword` or `logout`.
- **All rules are enforced on the server**; the app only mirrors them for convenience.
- **Speed:** screens open instantly from a saved copy of the last response, then refresh.

## Sheets

| Tab | Columns / purpose |
|---|---|
| Users | Username, Password(hash), Name, Manager, TokenEpoch, Role, MustChange, AppVersion, AppCode, LastSeen |
| Attendance | One row per check-in (server time, GPS, address, selfie id) |
| Leaves | Requests, status, application picture id |
| NightHold | One row per night per person |
| Notices · Holidays · Profiles | Admin notices, custom holidays, profile data |
| ManualEntry | Id, Kind, Date, Scope, Target, Time, CreatedBy, CreatedOn, Active |

Night-hold hours live in the script's **Script Properties** (`NIGHT_OPEN`, `NIGHT_CLOSE`).

## Project layout

```
.github/workflows/
  build.yml            Builds, numbers, signs and publishes the APK
  apply-update.yml     Unpacks an uploaded update.zip into the project
Code.gs                Apps Script backend (pasted into Apps Script, not part of the zip)
app/
  build.gradle
  src/main/
    AndroidManifest.xml
    assets/bd_locations.txt          64 districts → thanas
    java/com/example/attendance/
      Api.kt                Server URL, session, API helper
      Security.kt           Encrypted storage, wipe-on-logout, fake-GPS check
      Cache.kt              Saved-response cache for instant screens
      Admin.kt / AdminActivity.kt   Admin Panel (6 tabs)
      LiveLocation.kt       Reliable live GPS fix
      Reminders.kt          Notification-bar reminders (WorkManager)
      MainActivity.kt       Home
      AttendanceActivity.kt Selfie + location check-in
      LeaveActivity.kt      Leave + balances
      NightHoldActivity.kt  Night hold
      CalendarActivity.kt   Calendar
      TeamActivity.kt       Manager team view + approvals
      ProfileActivity.kt    My Profile
      AppUpdate.kt          In-app update: download, verify, install
      ChangePasswordDialog.kt, NoticesActivity.kt, NoticeAlerts.kt, Photos.kt, Ui.kt, …
    res/                    Layouts, colours, themes, drawables, xml/file_paths.xml
```

## Conventions

- Never overwrite `Api.kt`'s script URL when applying an update zip.
- Never commit the signing key or any password.
- Test `Code.gs` changes with a fake-Sheet harness before pasting them live.

Related: [[Setup Guide]] · [[Security]]
