# 🆘 Troubleshooting

Find your problem in the table. Still stuck? Ask your admin.

## Using the app

| Problem | Fix |
|---|---|
| **"Network or server error"** | Check the phone's internet and that `Config.SCRIPT_URL` is right (the worker address, or the latest `/exec` URL). If you use the Cloudflare Worker, see **Not allowed** below |
| **"Not allowed."** | The script has `APP_KEY` set but the request did not come through the worker. Check the app calls the worker address, that the worker's `APP_KEY` secret equals the Script Property exactly, or delete the Script Property. See [[Cloudflare Front Door]] |
| **"Many people are asking for codes right now"** | The app-wide limit of 20 reset codes an hour was reached. Try again later, or ask an admin to reset the password |
| **"Getting your location…" takes long** | Switch Location ON (High accuracy), go near a window or outside. After 45 seconds tap **Retry**. See [[Attendance]] |
| **A tracked person has no points, or gaps in the route** | The person's phone needs the **updated app**, **Location switched on** and the app's battery use set to **Unrestricted** (Android Settings → Apps → SAM BOND → Battery). Points start only after attendance is submitted, and the app must have been open once after that. Some brands (Xiaomi, Oppo, Vivo, Huawei…) stop background apps: allow *Autostart* / *Run in background*. After a restart or a force-stop, open the app once. See [[Admin Guide]] |
| **Team shows no 🛰️ Movement line** | The person has no **📍 Track movement** tick, or `Code.gs` was not deployed as a **New version** after the update. The line shows for people with the tick who have marked attendance that day |
| **Capture Selfie button does not appear** | Do what the camera picture asks (blink / turn your head / smile) with only your face in view, in good light; take off sunglasses or a mask. After 15 seconds it restarts by itself. |
| **Driver: no Submit button** | A driver's Submit button only shows after the **car meter picture** is verified. Take the selfie, then use the second card (back camera) to take the meter picture. If it says *No km number could be read*: move closer, hold steady, avoid shine, use 🔦, tap the picture to focus, then **Retake car meter**. The app must be the latest version. See [[Attendance]] |
| **Driver: no "Submit Day End" button** | It only shows after the new **car meter picture** is verified. Tap **📷 Start Day End**, take the meter picture with the back camera and fix a *No km number could be read* with **Retake car meter** (closer, steady, no shine, 🔦). The 🏁 Day end card only shows for a driver **after today's attendance is marked**, and not any more once the day end is sent. The app must be the latest version. See [[Attendance]] |
| **"Mark your attendance first: the day end comes after it."** | The driver has no attendance row for today **or for yesterday**. The day end goes to today's row, or, while there is no attendance for today yet, to yesterday's row (a day that ran past midnight). It cannot reach an older row: an admin can type the time into column **M** and the km into column **O** of that row by hand |
| **"Day end already submitted today (…)"** / **"…for 2026-10-31 (…)"** | The day end can be sent once a day; the first one stands. To correct a wrong km an admin edits column **O** of that row (the km driven is worked out again from it) |
| **A driver shows Present, never Late or Absent after 6 PM** | That is on purpose: drivers have **no cut-off times** (late line and 6 PM absent switch). They count as Absent only when a whole day has passed without attendance. Everybody else is unchanged. A person is a driver by the **Driver** right or `driver` in the Role cell |
| **Team: picking a day shows "needs the latest Code.gs"** | The script is older than the app. Paste the new `Code.gs` and deploy a **New version** (see [[Configuration]]) |
| **"Choose a date up to today."** | The Team screen can show today or any earlier day, not a future day |
| **"Location (GPS) is switched off"** | Turn Location on from the quick settings, then tap Retry |
| **"A fake / mock location was detected"** | Turn off any fake-GPS app, then retry |
| **"Too many wrong passwords"** | Wait the 15 minutes shown, or ask an admin to reset your password |
| **"Your session ended"** | Normal after a password change on another phone, a logout, or 30 days away. Sign in again |
| **Forced "choose a new password" pop-up** | Your password was temporary or too easy. Choose a new one (8+ characters) |
| **Night Hold says closed** | You are outside the night-hold hours. The screen shows today's hours |
| **Leave refused: "write the reason" / "attach a picture"** | Both are required: a reason of 3+ characters and a picture of the application |
| **Take photo does nothing** | Allow the Camera permission (Settings → Apps), or use *Choose picture* |
| **No reminders** | Check 👤 menu → *Attendance reminders*, allow notifications, set the app's battery to *Unrestricted*. They are checked about every 30 minutes |

## For admins

| Problem | Fix |
|---|---|
| **An admin action asks for a password** | Menu access, Active/Inactive, a notice for everyone, removing a notice and editing a profile or photo need **your own** password; after one correct entry it is not asked again for 15 minutes |
| **"That APK is signed with a different key"** | `RELEASE_CERT_SHA256` is set and the APK was signed with another key. Use the build signed with your four signing secrets, or clear the Script Property if you really changed the key |
| **"The signing certificate fingerprint is missing"** | The phone you publish from runs an older app version. Update it first |
| **A driver's meter can never be read** | Admin Panel → Entry → 🚗 Car meter check → turn the **number check OFF**: the picture is still required but any picture is enough. Or tell the driver to photograph the km counter alone, close and sharp |
| **Admin Panel isn't in the 👤 menu** | The person's **Role** cell must say `admin`; then refresh Home once |
| **App behaves the old way after editing `Code.gs`** | Deploy a **New version** |
| **Nothing is written to the Sheet** | The script must be bound to the Sheet or `SHEET_ID` set; run `setup` once |
| **Someone forgot their password** | Admin Panel → Users → **Reset password** (also lifts a lockout) |
| **Someone lost their phone** | In Apps Script run `revokeOneUser` (edit the username inside first) or `revokeEveryone` |
| **No ⬆️ Update card on Home** | The published *build number* must be higher than the installed one. Pull Home down to refresh it |
| **Update download fails or says "damaged"** | Check the internet and tap Update again; or upload the APK again from Admin → App |
| **📱 SMS: "not set up" or nothing arrives** | Run `authorizeSms` once in Apps Script; save the key + Device ID in Admin → 📱 SMS; the spare phone must be on, online, with the SimGate app. See [[SMS Notifications]] |
| **✉️ "E-mail is not allowed yet"** | In Apps Script run `authorizeEmail` once and approve. Then deploy a New version if you pasted new code |
| **✉️ Someone did not get the report** | They need a valid **Email** in My Profile; check their spam folder; Google allows about 100 mails a day |
| **A menu shows 🔒 "locked for your account"** | An admin locked it: Admin Panel → Users → 🔐 Menu access. Ask them to tick it again; then refresh Home |
| **🎯 "Cannot use this file" when uploading** | Use the original `.xlsx` (not a photo or PDF). The first rows must hold the column names (Username + Target, or Collection Date + Collection Amount) |
| **🎯 Someone sees "no target or collection for you"** | Their Username in the Excel files must be the same as their app Username |
| **Excel file will not open** | Re-download it; try Share and open in another app. Tell the developer which app complained |

## Building and installing

| Problem | Fix |
|---|---|
| **"Conflicting app signatures"** when installing | Uninstall the old app once, install the new one. Data is safe |
| **APK named `…-TEMP-KEY.apk` / won't update** | The four signing secrets are missing. Add them (see [[Setup Guide]]), uninstall the old app once, install the new one |
| **"App not installed as package conflicts"** | The APK was signed with a different key. Same fix as above |
| **Build APK fails** | Open the run's **Summary** — the *"Build failed – the real error"* box shows the line. The log is the `build-log` artifact |
| **Build is green but *Publish release* is red** | GitHub refused a pre-release with files (immutable releases). The APK is still in **Artifacts**; the current `build.yml` saves such builds as a draft release |
| **A push to the repo is refused (403)** | Upload through the GitHub website (**Add file → Upload files**) instead |

Related: [[FAQ]] · [[Updating the App]]
