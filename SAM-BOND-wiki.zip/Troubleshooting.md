# 🆘 Troubleshooting

Find your problem in the table. Still stuck? Ask your admin.

## Using the app

| Problem | Fix |
|---|---|
| **"Network or server error"** | Check the phone's internet and that `Config.SCRIPT_URL` is the latest `/exec` URL |
| **"Getting your location…" takes long** | Switch Location ON (High accuracy), go near a window or outside. After 45 seconds tap **Retry**. See [[Attendance]] |
| **"Location (GPS) is switched off"** | Turn Location on from the quick settings, then tap Retry |
| **"A fake / mock location was detected"** | Turn off any fake-GPS app, then retry |
| **"Too many wrong passwords"** | Wait the 15 minutes shown, or ask an admin to reset your password |
| **"Your session ended"** | Normal after a password change on another phone, a logout, or 30 days away. Sign in again |
| **Forced "choose a new password" pop-up** | Your password was temporary or too easy. Choose a new one (8+ characters) |
| **Night Hold says closed** | You are outside the night-hold hours. The screen shows today's hours |
| **Leave refused: "write the reason" / "attach a picture"** | Both are required: a reason of 3+ characters and a picture of the application |
| **Take photo does nothing** | Allow the Camera permission (Settings → Apps), or use *Choose picture* |
| **No reminders** | Check 👤 menu → *Attendance reminders*, allow notifications, set the app's battery to *Unrestricted*. They are checked about every 30 minutes |

## For admins

| Problem | Fix |
|---|---|
| **Admin Panel isn't in the 👤 menu** | The person's **Role** cell must say `admin`; then refresh Home once |
| **App behaves the old way after editing `Code.gs`** | Deploy a **New version** |
| **Nothing is written to the Sheet** | The script must be bound to the Sheet or `SHEET_ID` set; run `setup` once |
| **Someone forgot their password** | Admin Panel → Users → **Reset password** (also lifts a lockout) |
| **Someone lost their phone** | In Apps Script run `revokeOneUser` (edit the username inside first) or `revokeEveryone` |
| **No ⬆️ Update card on Home** | The published *build number* must be higher than the installed one. Pull Home down to refresh it |
| **Update download fails or says "damaged"** | Check the internet and tap Update again; or upload the APK again from Admin → App |
| **📱 SMS: "not set up" or nothing arrives** | Run `authorizeSms` once in Apps Script; save the key + Device ID in Admin → 📱 SMS; the spare phone must be on, online, with the SimGate app. See [[SMS Notifications]] |
| **✉️ "E-mail is not allowed yet"** | In Apps Script run `authorizeEmail` once and approve. Then deploy a New version if you pasted new code |
| **✉️ Someone did not get the report** | They need a valid **Email** in My Profile; check their spam folder; Google allows about 100 mails a day |
| **A menu shows 🔒 "locked for your account"** | An admin locked it: Admin Panel → Users → 🔐 Menu access. Ask them to tick it again; then refresh Home |
| **🎯 "Cannot use this file" when uploading** | Use the original `.xlsx` (not a photo or PDF). The first rows must hold the column names (Username + Target, or Collection Date + Collection Amount) |
| **🎯 Someone sees "no target or collection for you"** | Their Username in the Excel files must be the same as their app Username |
| **Excel file will not open** | Re-download it; try Share and open in another app. Tell the developer which app complained |

## Building and installing

| Problem | Fix |
|---|---|
| **"Conflicting app signatures"** when installing | Uninstall the old app once, install the new one. Data is safe |
| **APK named `…-TEMP-KEY.apk` / won't update** | The four signing secrets are missing. Add them (see [[Setup Guide]]), uninstall the old app once, install the new one |
| **"App not installed as package conflicts"** | The APK was signed with a different key. Same fix as above |
| **Build APK fails** | Open the run's **Summary** — the *"Build failed – the real error"* box shows the line. The log is the `build-log` artifact |
| **Build is green but *Publish release* is red** | GitHub refused a pre-release with files (immutable releases). The APK is still in **Artifacts**; the current `build.yml` saves such builds as a draft release |
| **A push to the repo is refused (403)** | Upload through the GitHub website (**Add file → Upload files**) instead |

Related: [[FAQ]] · [[Updating the App]]
