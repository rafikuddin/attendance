# 🛡 Admin Guide

An **admin** is any user whose **Role** cell in the **Users** sheet says `admin`. Admins see **Admin Panel** in the 👤 menu on Home. The tab bar scrolls sideways:

**👥 Users · 📢 Notices · 🎉 Holiday · 📝 Entry · 📊 Report · 🎯 Targets · 📱 SMS · 🌴 Leave · 🧭 Menu · 📲 App**

> [!NOTE]
> Admin rights are checked **on the server for every request**. Remove `admin` from the Role cell and it takes effect at once.

## Make your first admin

Only someone who can **edit the Sheet** can do this (so an ordinary user can never create an admin).

1. Open `Code.gs` in Apps Script, find `function makeAdmin()`, and change `'manager1'` to your username.
2. Select `makeAdmin` and press **Run** — *or* type `admin` into the **Role** cell yourself.
3. Open or refresh Home; **Admin Panel** appears in the 👤 menu.

---

## 👥 Users

- **Search** by name, Employee ID or manager.
- **Add a user:** Employee ID, name, manager, optional admin role. Needs **your own password**.
- **Reset a password:** type a temporary one, or leave it blank and the server makes one (shown **once**, with a **Copy** button that clears your clipboard after 1 minute). Needs **your own password**. The person is signed out everywhere and must choose their own password at the next sign-in. A reset also lifts a "too many wrong passwords" pause.
- Each card shows the **app version** on that person's phone: 🟢 latest · 🟠 *needs update* · ⚪ not seen yet.
- **📝 Sign-up requests** — people can ask for an account on the login page (their e-mail is verified with a code). In **Users → 📝 Sign-up requests** you see who is waiting: **Approve** (your password + the line manager; the account is created and they are told by e-mail) or **Reject**. The tick box **Let people create accounts on the login page** turns sign-up on or off. Nobody can sign in before you approve.
- **🔑 Forgot password by e-mail** — people can reset their own password from the login page with a code e-mailed to their **My Profile** address. One-time: run `authorizeEmail` in the Apps Script editor (the same permission as e-mail reports). Anyone without an e-mail in My Profile, or inactive, cannot use it; use **Reset password** on their card instead.
- **⛔ Active / Inactive** — every user card shows **Active** (green) or **Inactive** (red) and a **Make Inactive / Make Active** button. An inactive person cannot sign in, is signed out on every phone immediately and is left out of the people lists; their data stays. They are also left out of **team counts / total members, SMS and notification recipients, reports, Target vs Collection and survey audiences**; anyone who reported to an inactive manager moves up to the next active manager. You cannot make yourself inactive. Stored in Users column **L (Inactive)**. **Make Inactive asks two questions: the _Last working day_ (a date, within a year of today) and _Remarks_.** Both are saved on the Users tab (columns **LastWorkingDay**, **InactiveRemarks**, **InactiveBy** = who and when; created automatically) and shown on the person's card. An **e-mail is sent automatically to every active line manager above the person (their manager, that manager's manager, …) and to every active admin**: name, Employee ID, last working day, remarks, who did it. People with no e-mail in My Profile, and inactive managers/admins, are skipped (the app tells the admin how many were e-mailed and how many have no e-mail). If the mail service fails or the daily quota is used up, the account is still made inactive. Making someone Active again clears the date/remarks and sends no mail. The account is switched off immediately; the last working day is a record, not a timer. Needs the same mail permission as the other e-mails (`authorizeEmail`).
- **🔐 Menu access** — decide **which menus a person may use**. Tick = allowed, untick = **locked**: *Attendance, Leave, Night Hold, Calendar, Team, Notices, My Reports, Target vs Collection, My Profile, Manual entry* and, for an **admin**, **🛠 Admin Panel** (a locked admin loses the Admin Panel entry and the server refuses their admin actions; you can **never lock your own** Admin Panel, so one admin can always unlock another). A locked menu is greyed with a 🔒 on that person's phone and the **server refuses it** too. The card shows *🔒 Locked: …*. **Unlock all** opens everything again. The button **🔐 Menu access for several people** at the top applies one setting to a whole list (it *replaces* their current settings). The change reaches the phone the next time Home loads (open the app or tap ⟳ on Home); the server refuses a locked option at once. Admin rights themselves still come from the **Role** cell; the 🛠 Admin Panel tick only switches the panel off for that admin. *Calendar* and *Profile* hold the person's own data, so locking them hides the screen. Stored in Users column **K (Locked)**; you can also type keys such as `leave,reports` there.
- **📅 Calendar** — that person's pay-period calendar, read-only: attendance with **time and location**, late days, leave, holidays and night holds with hotel and location. Tap *🗺 on map* to open Maps. You see *when and where*, **not** selfies or leave pictures (unless you are above them in the chain).
- **👤 Profile** — view and change their photo, phones, email, emergency contact, bike and laptop. No password is needed for this.

## 📢 Notices

Post a **title + message** to everyone. (Managers can also post a notice for their **own team** from the Notices screen; admins do not see those unless they are in that team.) Shown for **7 days** by default (up to **90**). Remove a notice at any time. Tick **📱 Also send as an SMS** to text it to everyone's phone too — see [[SMS Notifications]].

## 🎉 Holiday

Pick a **date** and a **name**. That day behaves like Friday for everyone: nobody is absent, the Team view shows *Off*, Calendar and Home show the holiday name. Remove it and it counts as a normal working day again.

## 📝 Entry

Two tools in one tab.

### Night hold hours
Choose **when people may submit** a night hold — for example *9 PM → 6 AM* or *8 PM → 5 AM*. If the closing hour is earlier than the opening hour, the window runs through midnight. The server enforces it, and **every phone updates its Night Hold screen text automatically**.

### Manual entry for a chosen date
Open **one past date (or today)** for **attendance** or **night hold**, then choose **who** may fill it:

| Scope | Who |
|---|---|
| **Everyone** | All users |
| **A whole team** | A manager and everyone below them |
| **Selected people** | A searchable list |

- Optional **time to record** (24-hour, e.g. `09:00`). Empty = the real time.
- Needs **your own password**.
- The chosen people see **📝 Manual entry** in their 👤 menu, pick the date and fill the normal screen. **Live selfie and GPS are still required.**
- Each person can fill each opened date **once**. Entries are marked **[Manual]** in the Address column, and opened dates are kept on a **ManualEntry** tab.
- Switch a date off with **✕** — people who have not filled it in yet lose it at once.

## 📊 Report

Download Excel files, or **✉️ e-mail every person their own report**. Details on [[Reports and Excel]].

## 🎯 Targets

Upload the **Target** Excel file and the **Sale Collection** Excel file so everyone can see their target against what they collected (managers: their team too). Needs **your own password**. Full steps on [[Target vs Collection]].

## 📱 SMS

Set up free text messages (SimGate), see how many of the monthly allowance are left, send a test to yourself, and send any message to everyone, a team or selected people. Needs **your own password**. Full steps on [[SMS Notifications]].

## 🌴 Leave
Set how many days a year each kind of leave gives: **Casual, Sick, Earn and Paternity**. Start values are 10 · 14 · 17 · 3.

1. Open **Admin Panel → 🌴 Leave**.
2. Change a number (a whole number from 0 to 365). **↺ Fill in the standard days** puts 10 · 14 · 17 · 3 back.
3. Press **Save leave days**. The app lists exactly what changes; confirm with **Save**.

> [!NOTE]
> The new numbers apply to **everyone** straight away: the Leave screen, Home and the check when someone applies. A person who already used more than the new number simply has **0 left**; leave that is already approved or pending is never changed or cancelled.

The numbers are kept in the Script Property `LEAVE_QUOTA`. If that value is ever damaged, the standard days are used.

## 🧭 Menu
Choose the **order** of the menus, for everyone.

1. Open **Admin Panel → 🧭 Menu**. Three lists are shown: **Side menu: Menu**, **Side menu: Settings** and **Admin Panel tabs**.
2. Move an entry with **▲** and **▼**.
3. Press **Save the order** and confirm. **↺ Standard order** puts the original order back (then press Save).

The Admin Panel tab bar re-orders straight away. Phones get the new side-menu order the next time the Home screen loads. *Home* always stays at the top of the side menu.

> [!NOTE]
> This only changes the **order**. Who may see or use an entry is still decided by [Menu access](Admin-Guide#-users) and the person's role.

In the side menu, **🛠 Admin Panel** opens like a folder: tap it to show or hide its tabs (in your chosen order), and tap a tab to go straight to it. The search box also finds the tabs.

## 📲 App

Publish a new app version for everyone. Details on [[Updating the App]].

**Compulsory updates:** the publish box **Compulsory: people cannot use the app until they install it** is ticked by default. Phones with an older build then show only a full-screen **Update required** page (Download and install / Check again, Back does nothing) until the new build is installed. Use **Make it optional** on the published version's card (needs your password) to release everyone.

---

## Admin checklist

- [ ] Run `securityCheck` in Apps Script now and then (flags easy passwords and Manager loops).
- [ ] Delete sample rows such as `manager1` / `demo` if they still exist.
- [ ] Turn on **2-Step Verification** on the Google account that owns the Sheet.
- [ ] Add holidays before they happen.
- [ ] Lost phone? Run `revokeOneUser` (edit the username inside it first) or `revokeEveryone` in Apps Script.

Related: [[Security]] · [[Configuration]]
