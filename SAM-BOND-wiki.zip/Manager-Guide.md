# 👥 Manager Guide

A **manager** is anyone whose username appears in another user's **Manager** column in the Google Sheet. There are **no hard-coded roles** — Employee → ZM/ASM → RSM/DSM → SM → Operation Manager (or any structure) works, with unlimited levels.

## The Team screen

Open **Team** (bottom bar — managers only).

- **Status today** for each direct report: Present · Late · On Leave · Absent · Off · Pending.
- Their **selfie and location** for today.
- A **live roll-up** for any report who manages a team of their own.
- **Drill down:** tap a manager to see their team, all the way down to individual employees.

## Approving leave

- Your Team screen lists leave requests from **everyone below you** (direct reports and people further down).
- Tap a sub-manager to see just their team's requests.
- **Pending requests are listed first.** Decided ones show **Approved by <name> · date** (or Rejected by).
- Open a request, view **📎 the leave application picture**, then **Approve** or **Reject**.

| Rule | Detail |
|---|---|
| Who can decide | Only a supervisor **above** that person in the chain |
| Own leave | **Never** — nobody approves their own |
| Outside your chain | The server refuses |

## 🎯 Target vs Collection

Open the **🎯 Target vs Collection** tile on Home: your own numbers, then your team total and every person below you (tap one for day by day). See [[Target vs Collection]].

## Notices for your team

Open **Notices** (bell on Home) and tap **✍️ Post a notice**. Only **you and everyone below you** see it. You can remove your own notices; nobody else can. Tick **📱 Also send as an SMS to my team** to text it to their phones too (see [[SMS Notifications]]). See [[Notices and Reminders]].

## Reports

**👤 menu → 📊 My Reports** — choose **👤 Only me** or **👥 My team** (you plus everyone below you), Attendance or Night hold, and a period. See [[Reports and Excel]].

## Who can see what

| Item | Visible to |
|---|---|
| Selfies and leave-application pictures | The person and every supervisor above them |
| Profile photo | The person, supervisors above them, admins |
| Team views | Only down your own chain |

## Reminders for managers

From **9:10 AM** you get *👥 N team members not marked yet* with the names, so nobody is chased during the grace period. Turn it off in the 👤 menu — see [[Notices and Reminders]].

Related: [[Leave]] · [[Admin Guide]]


## 🪪 Team members: profile and calendar of your people

An admin can give a line manager the right **Can see Profile & Calendar of own team** (Admin Panel → Users → the manager → 🔐 Menu access → *Extra rights*). With it you get **🪪 Team members** in the 👤 menu:

- a searchable list of **only the people below you** (direct and indirect reports);
- **👤 Profile** opens their profile and **📅 Calendar** their attendance calendar (times, locations, leave, night holds). Both are **read only**;
- it gives no other admin power, and nobody outside your team can be opened (the server checks every request).

Not there? Ask your admin to tick the right for you.
