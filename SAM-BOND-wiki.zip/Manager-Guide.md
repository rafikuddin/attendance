# 👥 Manager Guide

A **manager** is anyone whose username appears in another user's **Manager** column in the Google Sheet. There are **no hard-coded roles** — Employee → ZM/ASM → RSM/DSM → SM → Operation Manager (or any structure) works, with unlimited levels.

## The Team screen

Open **Team** (bottom bar — managers only).

- **Status today** for each direct report: Present · Late · On Leave · Absent · Off · Pending.
- Their **selfie and location** for today.
- For a **driver**: the **🚗 car meter** picture and km from the morning, and the **🏁 day end** (time, km, **km driven**, and the picture) once it is sent, or *🏁 Day end · not yet* until then. Tap a line to open its picture.
- A **live roll-up** for any report who manages a team of their own.
- **Drill down:** tap a manager to see their team, all the way down to individual employees.
- **Team Today numbers** (Present, Late, On Leave, Off, Absent, Pending, and the *members* total) count **everybody below you at every level, line managers included**. **Tap a number** to see the names behind it, in a full-height list with a **search box** (name or ID). Each row shows the person's initials, name, Employee ID, **base name** (from their Profile) and the time (or leave type). **Tap a person to open their calendar** (admins get the full view; a line manager needs the *Team members* right from an admin).

## Approving leave

- Your Team screen lists leave requests from **everyone below you** (direct reports and people further down).
- Tap a sub-manager to see just their team's requests.
- **Pending requests are listed first.** Decided ones show **Approved by <name> · date** (or Rejected by).
- Open a request, view **📎 the leave application picture**, then **Approve** or **Reject**.

| Rule | Detail |
|---|---|
| Who can decide | Only a supervisor **above** that person in the chain |
| Own leave | **Never** — nobody approves their own |
| Outside your chain | The server refuses |

## 🎯 Target vs Collection

Open the **🎯 Target vs Collection** tile on Home: your own numbers, then your team total and every person below you (tap one for day by day). See [[Target vs Collection]].

## Notices for your team

Open **Notices** (bell on Home) and tap **✍️ Post a notice**. Only **you and everyone below you** see it. You can remove your own notices; nobody else can. Tick **📱 Also send as an SMS to my team** to text it to their phones too (see [[SMS Notifications]]). See [[Notices and Reminders]].

## Reports

**👤 menu → 📊 My Reports** — choose **👤 Only me** or **👥 My team** (you plus everyone below you), Attendance or Night hold, and a period. See [[Reports and Excel]].

## Who can see what

| Item | Visible to |
|---|---|
| Selfies and leave-application pictures | The person and every supervisor above them |
| A driver's **car meter picture** and km, and the **day end** picture, km and km driven | The driver and every supervisor above them |
| Profile photo | The person, supervisors above them, admins |
| Team views | Only down your own chain |

## Reminders for managers

From **9:10 AM** you get *👥 N team members not marked yet* with the names, so nobody is chased during the grace period. Turn it off in the 👤 menu — see [[Notices and Reminders]].

Related: [[Leave]] · [[Admin Guide]]


## 🌙 Night hold summary
Under the Team Today numbers, a **🌙 NIGHT HOLD** block shows the **latest night** (tonight once the night hold hours have opened, otherwise last night). Tap the date chip to look at any earlier night.
- **Total night holds** (for example *37 of 130*) counts everybody below you. Tap it to see **every person with their name, hotel, thana / district, date and time**; tap a row to open the place on the map. A search box finds a name, ID or place.
- Four chips under the heading switch the view: **Night** (one night, with the date chip), **Previous**, **Current** and **Next** pay cycle (26th to 25th, for example *26 Oct – 25 Nov*). For a cycle the total reads *night holds · by N people* and each team shows *night holds by people of team size*. The lists run newest night first, with the date on every row. *Next* stays empty until those nights come.
- Below it, **team by team**: one row per direct report who has a team (that person and everybody under them), plus *Direct reports* for people with nobody below them. Each shows *submitted of total*; tap a row to see only that team's night holds.

## 📇 Team members: profile and calendar of your people

An admin can give a line manager the right **Can see Profile & Calendar of own team** (Admin Panel → Users → the manager → 🔐 Menu access → *Extra rights*). With it you get **📇 Team members** in the 👤 menu:

- a searchable list of **only the people below you** (direct and indirect reports);
- **👤 Profile** opens their profile and **📅 Calendar** their attendance calendar (times, locations, leave, night holds). Both are **read only**;
- it gives no other admin power, and nobody outside your team can be opened (the server checks every request).

Not there? Ask your admin to tick the right for you.

## 🙂 Face check notes
When a person's selfie does not match their usual face, their row on **Team** shows ⚠️ *Face does NOT match the usual face* (with a score), and their **Calendar** shows the score for every day. This is only a flag: the attendance counts. Look at the selfie yourself, and talk to the person if it looks like somebody else.

## 📝 Late reasons
On the **Team** screen, a person who is *Late* shows **📝 Late reason: …** (or *No late reason yet*). In their **Calendar** (Team members) the late day also shows the reason.
