# 👥 Manager Guide

A **manager** is anyone whose username appears in another user's **Manager** column in the Google Sheet. There are **no hard-coded roles** — Employee → ZM/ASM → RSM/DSM → SM → Operation Manager (or any structure) works, with unlimited levels.

## The Team screen

Open **Team** (bottom bar — managers only).

- **Status today** for each direct report: Present · Late · On Leave · Absent · Off · Pending.
- Their **selfie and location** for the day shown. **Tap the small selfie** to see it big. **Tap the address** (underlined) to open the place on the map; with no address the coordinates are shown and open the map the same way.
- **📅 Look at an earlier day.** Under *TEAM TODAY* a date bar shows the day: **‹** the day before, the **date** (tap it to pick any day up to today), **›** the day after, and **Today** to come back. The numbers, the hero card and the whole attendance list change to that day: status, time, selfie, address, late reason, and for a day that is over nobody is *Pending* any more. Friday and holidays show *Off*; *Own attendance: N day(s) this month* counts up to that day. Tap a sub-manager and you see that team on the same day. The **🌙 Night hold** block keeps its own date chip, and the **📝 Leave applications** tiles always count the current salary cycle.
- For a **driver**: the **🚗 car meter** picture and km from the morning, and the **🏁 day end** (time, km, **km driven**, and the picture) once it is sent, or *🏁 Day end · not yet* until then. Tap a line to open its picture.
- **Drivers have no cut-off times:** a driver is never *Late* and is *Pending* (not *Absent*) until the day is over, even after 6 PM; they can still submit at any hour. You are not reminded about drivers who have not marked yet. A driver's day end after midnight appears on the card of the **day it closes** (time *… (next day)*).
- For a person your admin set to **📍 Track movement**: a line **🛰️ Movement · 14 points · last 04:50 PM · tap to see the route** (for the day shown in the date bar; *no points yet* until the first one arrives). Tap it to open the **📍 Movement** screen: a day bar (‹ ›, tap the date to pick a day), the number of points, the **km moved**, one line per point (*time · metres from the previous point · ±accuracy*, *stayed* when the step is under 25 m), and **🗺️ See the route on the map** (opens Google Maps with the whole day as one route). Tap a line to see that spot on the map. The phone sends a point every 10 minutes after the attendance until 6 PM (a driver until the Day End), so gaps mean the phone was off, had no internet, or stopped the app. Only the person, the managers above them and admins can open it.
- A **live roll-up** for any report who manages a team of their own.
- **Drill down:** tap a manager to see their team, all the way down to individual employees.
- **Team Today numbers** (Present, Late, On Leave, Off, Absent, Pending, and the *members* total) count **everybody below you at every level, line managers included**. **Tap a number** to see the names behind it, in a full-height list with a **search box** (name or ID). Each row shows the person's initials, name, Employee ID, **base name** (from their Profile) and the time (or leave type). **Tap a person to open their calendar** (admins get the full view; a line manager needs the *Team members* right from an admin).

## Approving leave

- The **📝 Leave applications** tiles at the top of your Team screen count the leave requests of **everyone below you** (direct reports and people further down). You approve and reject there (see the next section).
- Tap a sub-manager to see just their team's requests.
- Tap **⏳ Pending** to go through the requests that are waiting. Tap **✅ Approved** or **❌ Rejected** to see who decided and when (**Approved by <name> · date**, or Rejected by).
- On a request tap **📎 View leave application** to see the picture, then **Approve** or **Reject**.

| Rule | Detail |
|---|---|
| Who can decide | Only a supervisor **above** that person in the chain |
| Own leave | **Never** — nobody approves their own |
| Outside your chain | The server refuses |

## 🎯 Target vs Collection

Open the **🎯 Target vs Collection** tile on Home: your own numbers, then your team total and every person below you (tap one for day by day). See [[Target vs Collection]].

## Notices for your team

Open **Notices** (bell on Home) and tap **✍️ Post a notice**. Only **you and everyone below you** see it. You can remove your own notices; nobody else can. Tick **📱 Also send as an SMS to my team** to text it to their phones too (see [[SMS Notifications]]). See [[Notices and Reminders]].

## Reports

**👤 menu → 📊 My Reports** — choose **👤 Only me** or **👥 My team** (you plus everyone below you), Attendance or Night hold, and a period. See [[Reports and Excel]].

## Who can see what

| Item | Visible to |
|---|---|
| Selfies and leave-application pictures | The person and every supervisor above them |
| A driver's **car meter picture** and km, and the **day end** picture, km and km driven | The driver and every supervisor above them |
| Profile photo | The person, supervisors above them, admins |
| Team views | Only down your own chain |

## Reminders for managers

From **9:10 AM** you get *👥 N team members not marked yet* with the names, so nobody is chased during the grace period. Turn it off in the 👤 menu — see [[Notices and Reminders]].

Related: [[Leave]] · [[Admin Guide]]


## 📝 Leave applications of the salary cycle
Between the Team Today numbers and **🌙 Night hold** you see **📝 Leave applications**, with the cycle under it (for example *Current salary cycle · 26 Oct – 25 Nov*). Three tiles count the leave requests of **everybody below you**:

| Tile | Counts |
|---|---|
| ⏳ **Pending** | requests still waiting for a decision |
| ✅ **Approved** | requests that were approved |
| ❌ **Rejected** | requests that were rejected |

- A request belongs to the cycle when **any day of the leave falls inside it** (the cycle runs 26th to 25th). Salary is worked out from the leave days, so the tiles follow the days of the leave, not the day it was sent. A request for 24–28 Nov shows in the cycle that ends on 25 Nov and again in the next one.
- **Tap a tile** to open the list: name, leave type and days, dates, reason, the 📎 application picture and who decided. A search box (name or ID) appears when the list is long.
- A **pending** request can be **approved or rejected right there**. The list and the numbers update by themselves, so you can go through the pending ones one after another.
- The cycle is always the **current** one, whichever day you picked in the date bar.
- A pending request whose leave days are in **another** salary cycle (an old one nobody decided, or one for a later month) is not in the numbers, but it is never lost: a line under the tiles says how many there are, and the **⏳ Pending** list shows them under **Pending in other salary cycles**, so you can decide them too.
- There is no separate *Leave Requests* list at the bottom of the Team screen any more: the three tiles replace it.

## 🌙 Night hold summary
Under the Team Today numbers and the Leave applications tiles, the **🌙 Night hold** block shows the **latest night** (tonight once the night hold hours have opened, otherwise last night). It has four parts:

- **Title line:** *Night hold* with what is shown under it (*One night*, or for a pay cycle for example *Current pay cycle · 26 Oct – 25 Nov*). For one night the **date button** on the right opens any earlier night.
- **One switch for the view:** **Night** (one night), **Previous**, **Current** or **Next** pay cycle (26th to 25th). *Next* stays empty until those nights come.
- **Total night holds:** the big number with a bar, for example *37 of 130 members* (everybody below you). For a cycle it reads *night holds by N of 130 members*. **Tap it** to see **every person with their name, hotel, thana / district, date and time**; tap a row to open the place on the map. A search box finds a name, ID or place. Cycle lists run newest night first, with the date on every row.
- **By team (hidden at first):** under the total tap the button **▾ Show details by team**. It opens one list with a row for each direct report who has a team (that person and everybody under them), plus *Direct reports* for people with nobody below them. Each row shows the team name, **how many of how many** (*2 / 82*; for a cycle *people / members* with *7 night holds* under the bar), a thin bar and an arrow. Teams with nobody on night hold are shown quietly. **Tap a row** to see only that team's night holds. The button now reads **▴ Hide details by team**: tap it to close the list again. The list stays open while you switch Night / Previous / Current / Next or pick another date, and is hidden again each time you open a Team screen.

## 📇 Team members: profile and calendar of your people

An admin can give a line manager the right **Can see Profile & Calendar of own team** (Admin Panel → Users → the manager → 🔐 Menu access → *Extra rights*). With it you get **📇 Team members** in the 👤 menu:

- a searchable list of **only the people below you** (direct and indirect reports);
- **👤 Profile** opens their profile and **📅 Calendar** their attendance calendar (times, locations, leave, night holds). Both are **read only**;
- it gives no other admin power, and nobody outside your team can be opened (the server checks every request).

Not there? Ask your admin to tick the right for you.

## 🙂 Face check notes
When a person's selfie does not match their usual face, their row on **Team** shows ⚠️ *Face does NOT match the usual face* (with a score), and their **Calendar** shows the score for every day. This is only a flag: the attendance counts. Look at the selfie yourself, and talk to the person if it looks like somebody else.

## 📝 Late reasons
On the **Team** screen, a person who is *Late* shows **📝 Late reason: …** (or *No late reason yet*). In their **Calendar** (Team members) the late day also shows the reason.
