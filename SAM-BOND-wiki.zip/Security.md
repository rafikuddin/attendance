# 🔒 Security

How the app protects people and data — and what it cannot protect.

## Built in

| Area | Protection |
|---|---|
| **Passwords** | Stored only as salted **PBKDF2-SHA256** hashes. The app never saves your password |
| **Sessions** | A signed token (encrypted with the Android Keystore), expires in 30 days, renewed while you use the app, dead the moment you change your password, log out, or an admin revokes it |
| **Weak passwords** | Too short or easy (`1234`, `12345678`, the username…) or admin-given → accepted once, then the server refuses **everything** except choosing a new password or signing out |
| **Brute force** | 5 wrong passwords pause the account 15 minutes, counted under a lock so parallel guesses can't slip through |
| **Photos & locations** | Selfie required, JPEG only, size-limited; coordinates must be real and inside the allowed area; fake-GPS flag rejected |
| **Who sees what** | Selfies and leave pictures: only the person and supervisors above. Team views: only down your own chain |
| **Admin actions** | Checked on the server every request. Adding a user, resetting a password, manual entry and publishing an update need the admin's **own password** again |
| **Formula injection** | Text typed on a phone (address, hotel, reason) is always stored as text |
| **App updates** | Published only by an admin; phones verify a SHA-256 fingerprint; Android installs only if the signing key matches |
| **Phone storage** | Backups disabled; saved data encrypted and wiped at logout; temporary passwords copied by admins are wiped from the clipboard after 1 minute |
| **Manual entry** | Only a date opened *for you*, once, not in the future; selfie/GPS checks still apply |

## Tools for admins

Run these from the Apps Script editor (**Run**, then **View → Logs**):

| Function | What it does |
|---|---|
| `securityCheck` | Finds accounts with easy passwords and flags them, spots Manager loops, lists admins. Never prints passwords |
| `upgradeSecurity` | Hashes plain-text passwords on an old sheet |
| `revokeOneUser` | Signs one person out everywhere (edit the username inside first) |
| `revokeEveryone` | Signs everyone out; weak-password accounts are flagged at next sign-in |

## Your checklist

- [ ] Turn on **2-Step Verification** on the Google account that owns the Sheet and script.
- [ ] Share the Sheet only with people who must edit it — **whoever can edit it can read every profile and change any account.**
- [ ] Keep the GitHub repo **private**, or limit write access — anyone who can push can change the app.
- [ ] Never store the signing key or passwords in the repo, README or wiki.
- [ ] Delete sample users (`manager1`, `demo`).
- [ ] Delete `app/debug.keystore` from the repo if it is still there.

## Known limits

> [!NOTE]
> Be honest about these when you explain the system to others.

- **The script URL is public** (anyone with the APK has it). Everything is built assuming anyone can call it.
- **Account pausing:** someone who knows a username can pause that account for 15 minutes by typing wrong passwords — but cannot get in.
- **Floods:** a flood of requests can slow everyone; Apps Script has no per-caller limits.
- **Fake GPS / stored photo:** a modified app or rooted phone can still lie about GPS or send an old photo. Only Play Integrity attestation would close this; it is not included. Managers reviewing selfies and locations is the practical control.
- **No biometric app lock**, no code obfuscation (R8), and the cached photos on the phone are not separately encrypted.
- **Reminders** are checked by the phone about every 30 minutes — not push.

Related: [[Admin Guide]] · [[Setup Guide]]
