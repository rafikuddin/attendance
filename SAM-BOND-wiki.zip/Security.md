# 🔒 Security

How the app protects people and data — and what it cannot protect.

## Built in

| Area | Protection |
|---|---|
| **Passwords** | Stored only as salted **PBKDF2-SHA256** hashes (150000 rounds, unpredictable salt). The app never saves your password |
| **Sessions** | A signed token (encrypted with the Android Keystore), expires in 30 days, renewed while you use the app, dead the moment you change your password, log out, or an admin revokes it |
| **Weak passwords** | Too short or easy (`1234`, `12345678`, the username…) or admin-given → accepted once, then the server refuses **everything** except choosing a new password or signing out |
| **Brute force** | 5 wrong passwords pause the account 15 minutes, counted under a lock so parallel guesses can't slip through |
| **Photos & locations** | Selfie required, JPEG only, size-limited; coordinates must be real and inside the allowed area; fake-GPS flag rejected |
| **Who sees what** | Selfies and leave pictures: only the person and supervisors above. Team views: only down your own chain |
| **Risky admin actions** | Menu access, active/inactive, notices for everyone, removing a notice and editing someone's profile or photo need the admin's **own password**; one correct password gives a 15-minute proof that is tied to that admin and sign-in |
| **E-mail alerts** | A reset code only works for the address it was mailed to; changing an account's e-mail mails the old address (an admin's change also signs the person out); repeated wrong passwords mail the owner and admins once per pause (naming the account, its base, the line manager and the place the guesses came from — see below); at most 20 reset codes an hour for the whole app |
| **Front door (optional)** | A Cloudflare Worker adds a secret key and limits requests per address; with `APP_KEY` set the script refuses anything without the key. See [[Cloudflare Front Door]] |
| **Admin actions** | Checked on the server every request. Adding a user, resetting a password, manual entry and publishing an update need the admin's **own password** again |
| **Formula injection** | Text typed on a phone (address, hotel, reason) is always stored as text |
| **App updates** | Published only by an admin; phones verify a SHA-256 fingerprint; Android installs only if the signing key matches. With `RELEASE_CERT_SHA256` set, the script also refuses an APK signed with another key |
| **Phone storage** | Backups disabled; saved data encrypted and wiped at logout; temporary passwords copied by admins are wiped from the clipboard after 1 minute |
| **Manual entry** | Only a date opened *for you*, once, not in the future; selfie/GPS checks still apply |

## Tools for admins

Run these from the Apps Script editor (**Run**, then **View → Logs**):

| Function | What it does |
|---|---|
| `securityCheck` | Finds accounts with easy passwords and flags them, spots Manager loops, lists admins. Never prints passwords |
| `upgradeSecurity` | Hashes plain-text passwords on an old sheet |
| `revokeOneUser` | Signs one person out everywhere (edit the username inside first) |
| `revokeEveryone` | Signs everyone out; weak-password accounts are flagged at next sign-in |

## 🙂 Face prints (biometric data)
A face print is personal data. It is made on the phone; the photo is not used for it elsewhere and only the numbers are saved in the **FaceRefs** sheet (not the picture). Tell your staff what is checked (the app tells each person once), keep the sheet limited to admins, and use **Reset face** when someone leaves. The check only **flags**; it never locks anyone out, and it is a phone-side check, so it is not proof against a modified app.

## Your checklist

- [ ] Turn on **2-Step Verification** on the Google account that owns the Sheet and script.
- [ ] Share the Sheet only with people who must edit it — **whoever can edit it can read every profile and change any account.**
- [ ] Keep the GitHub repo **private**, or limit write access — anyone who can push can change the app.
- [ ] Never store the signing key or passwords in the repo, README or wiki.
- [ ] Delete sample users (`manager1`, `demo`) if an old install still has them.
- [ ] Optional Script Properties: `SHEET_ID`, `APP_KEY` (with the Cloudflare Worker), `RELEASE_CERT_SHA256` (only an APK signed with your key can be published).
- [ ] Delete `app/debug.keystore` from the repo if it is still there.

## Known limits

> [!NOTE]
> Be honest about these when you explain the system to others.

- **The script URL is public** (anyone with the APK has it). Everything is built assuming anyone can call it.
- **Account pausing:** someone who knows a username can pause that account for 15 minutes by typing wrong passwords — but cannot get in.
- **Floods:** a flood of requests can slow everyone; Apps Script has no per-caller limits.
- **Fake GPS / stored photo:** a modified app or rooted phone can still lie about GPS or send an old photo. Only Play Integrity attestation would close this; it is not included. Managers reviewing selfies and locations is the practical control.
- **No biometric app lock**, no code obfuscation (R8), and the cached photos on the phone are not separately encrypted.
- **Reminders** are checked by the phone about every 30 minutes — not push.

Related: [[Admin Guide]] · [[Setup Guide]]

## 🚨 The "repeated wrong passwords" e-mail
When an account is paused after 5 wrong passwords, the account owner gets one e-mail (admins are hidden-copied) with: the **name and Employee ID**, the **Base**, the **line manager**, and **where the guesses came from** (the phone's last known location, its address and a Google Maps link). The sign-in screen sends that location with every sign-in and asks for location permission once; the server keeps the last wrong guess's place in a short-lived cache (about 20 minutes) for this e-mail only, never on a sheet, and forgets it after a correct password. If there is no location (permission off, or the request did not come from the app) the e-mail says *not known*. The location is the phone's own report, so treat it as a clue, not proof.
