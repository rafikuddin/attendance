# 🚀 Getting Started

For **every staff member**. It takes about five minutes.

## 1. Install the app

1. Your admin or manager sends you the APK (or the link to the **Releases** page).
2. Open it on your phone. If Android asks, allow **Install unknown apps** for the app you opened it from (Chrome, Files, WhatsApp…).
3. Tap **Install**. You need **Android 7.0 or newer**.

> [!NOTE]
> If Android says **"Conflicting app signatures"** or **"App not installed as package conflicts"**, an older copy is installed. Uninstall it once, then install the new one. Your data is safe — it all lives in the Google Sheet.

## 2. Sign in

- Type your **Employee ID** and **password** your admin gave you.
- Leave **Keep me signed in on this device** ticked on your own phone (you stay signed in for 30 days). **Untick it on a shared phone** — then the sign-in ends after 12 hours.

## 3. Choose your own password

A password an admin gave you is **temporary**. After your first sign-in a pop-up asks you to choose a new one. You cannot close it, and the app does nothing else until you do.

Good password:
- at least **8 characters**,
- not `12345678`, `1234`, your username, or any easy pattern.

> [!WARNING]
## No account yet?

On the login page tap **New here? Create account**. A full-screen page opens with three steps. **1 Details:** your full name, your **Employee ID**, your e-mail address and a password (twice), then **Send verification code**. **2 Verify e-mail:** a **6-digit code** is e-mailed to you; type it in. Each digit pops into its box and the sixth is checked by itself: a good code opens the padlock and shows a green check, a wrong one shakes red and lets you type again. You can ask for a new code after 30 seconds, or go back and fix your details. **3 Done.** Your request goes to the admins. **You can sign in only after an admin approves it** (you get an e-mail either way).

## Forgot your password?

On the login page tap **Forgot password?**, type your Employee ID and tap **Send code**. A **6-digit code** is e-mailed to the address saved in your **My Profile**. Type the code into the boxes: each digit pops in and the sixth is checked by itself (a good code opens the padlock with a green check, a wrong one shakes red and lets you try again). Then choose a new password (at least 8 characters). The code works for **10 minutes** and only once; after 5 wrong tries ask for a new one (3 codes per hour at most). No e-mail saved in My Profile? Ask your admin to reset your password.

> **5 wrong passwords pause the account for 15 minutes.** Wait it out, or ask an admin to reset your password.

## 4. Allow the permissions

| Permission | Why |
|---|---|
| 📷 **Camera** | Attendance selfie and leave application photo |
| 📍 **Location** | Live GPS for attendance and Night Hold |
| 🔔 **Notifications** (Android 13+) | Attendance reminders |

## 5. Know the screen

A **bottom bar** is on every screen:

**Home · Attendance · Leave · Team · Calendar · Night Hold**

(*Team* appears only for managers.) To refresh a screen, **pull it down and let go**: a round spinner appears at the top while it reloads (there is no refresh button). The **👤 side menu** on Home (search, all menus, ☀️/🌙 colour switch, log out) has *My Profile*, *My Reports*, *Change Password*, *Admin Panel* (admins), *Logout* and the app version.

---

**Next:** [[Attendance]] — your daily check-in.
