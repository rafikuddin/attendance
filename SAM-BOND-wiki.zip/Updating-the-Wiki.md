# 📚 Updating the GitHub Wiki from your phone

You can change the whole GitHub Wiki by uploading **one zip file**. No computer, no git.

## One-time setup (about 3 minutes)
1. **Turn the wiki on.** Repository → **Settings → Features → Wiki** (tick it).
2. **Create the first page by hand.** Open the repository's **Wiki** tab → **Create the first page** → **Save**. GitHub only creates the wiki's storage after this first save. You do this once.
3. **Add the workflow.** Repository → **Add file → Create new file**. Name it `.github/workflows/update-wiki.yml`, paste the contents of `update-wiki.yml` (given with the project files), and **Commit**.

## Every time you want to update the wiki
1. Upload your wiki zip (for example `SAM-BOND-wiki.zip`) to the **main page of the repository** (**Add file → Upload files**). The file name must contain the word **wiki** and end in `.zip`.
2. The **Update Wiki** workflow starts by itself (Actions tab). When it shows a green tick (about 30 seconds), the wiki is updated and the zip is removed from the repository.

## Good to know
- The zip is the **master copy**: the wiki becomes exactly what is in the zip. A page that is on the wiki but not in the zip is **removed**. Keep all pages in the zip.
- The zip must contain **Home.md**. Without it nothing is changed.
- Page names come from the file names: `Getting-Started.md` becomes the page *Getting Started*. `_Sidebar.md` and `_Footer.md` are the side menu and the footer.
- A folder inside the zip is fine, and so are images: a `images/` folder is kept, and a page can show one with `![](images/name.png)`.
- Only one wiki zip at a time. If two are in the repository the workflow stops and tells you.
- **Error "Could not open the wiki"?** Do the two setup steps for the wiki (tick Wiki, create the first page), then open **Actions → Update Wiki → Run workflow**; the zip is still there.
- The workflow does not touch the app, the build or `update.zip`.
