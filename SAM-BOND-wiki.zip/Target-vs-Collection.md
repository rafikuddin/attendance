# 🎯 Target vs Collection

Shows **how much each person has collected against their target**.

| Who | What they see |
|---|---|
| **Everyone** | Their **own** target, collected amount, remaining and % |
| **Managers** | Their own numbers **and everyone below them** (team total + each person, best % first) |
| **Admins** | **Everyone** |

Open it from the **🎯 Target vs Collection** tile on Home or from the 👤 menu. Tap a person to see **day by day**, **by dealer** (Dealer Code, Dealer Name and Base) and **by type**. Admins can also tap the orange "no Username" note to see that money **by dealer**. The colour shows progress: green 100% or more, orange 70% or more, red below 70%.

## Working days and RR (required rate)

At the **top of the dashboard** you see the **working days** of the period: **Passed**, **Remaining** and **Total**. The period is the whole month of the Collection report (for a report ending 15 Oct 2026 it is **1 Oct to 31 Oct 2026**).

- **Working day** = every day except **Fridays** and the holidays added in **Admin Panel → 🎉 Holiday**.
- **Passed** = working days up to the **last date in the Collection report** (or up to **today**, if the admin chooses that).
- **Remaining** = Total − Passed.

Every person card (and the team total) also shows **RR = (Target − Collection) ÷ Remaining working days**: the amount to collect **every working day** to reach the target. Someone who has already reached the target shows **✅ Target reached**; with no working days left it shows *No working days left*.

*Example (Oct 2026, no holidays): 26 working days, report up to 15 Oct → 13 passed, 13 remaining. Target ৳ 190,000, collected ৳ 20,000 → RR = (190,000 − 20,000) ÷ 13 = ৳ 13,077 a day.*

Collection dated outside the period is not counted.

## Admin: upload the two files

**Admin Panel → 🎯 Targets**

1. **Target file** (Excel `.xlsx`) — columns **Username, Name, Base Code, Base Name, Target**. One target per person.
2. **Sale Collection report** (Excel `.xlsx`) — the columns used are **Collection Date, Collection Amount, Collection Type, Username**, plus **Customer Code / Customer Name** (the dealer), **Base Code, Base Name** and **Name**. The **Username** decides who the money counts for. Dealer Code, Dealer Name, Base Code, Base Name and Name are saved with every line.

For each file: tap **Upload**, pick the file, check the summary the app shows, type **your own password** and confirm. The phone reads the Excel file itself; only the totals per day, person and type are sent to the server.

> [!WARNING]
> A new upload **replaces** the old one of the same kind. Upload the Target file when targets change (for example each month) and the Collection report whenever you have a newer one.

### Things to know

- **Rows without a Username** cannot be given to anyone. The app tells you how many rows and how much money, so you can fix the file. Admins also see this amount on the Target vs Collection screen.
- **Usernames must match the app Usernames** (for example `2816`). Targets for someone who is not in the Users tab are loaded but shown to nobody; the upload result lists them.
- **What counts as collected:** by default every *Collection Type* counts (Cash, Collection, Monthly Commission, Bank Charge…). In **🎯 Targets → What counts as collected** untick types that should not count (for example Bank Charge) and press **Save**.
- **Period and working days:** in **🎯 Targets → Period and working days** you can set your own Start and End dates, go back to the automatic month, and choose whether *passed days* count up to the last report date or to today.
- Dates like `06-Oct-2026`, `2026-10-06`, `06/10/2026` (day first) and real Excel dates are all understood.
- Stored on two tabs of the Google Sheet: **TargetData** and **CollectionData** (Date, Username, Type, Amount, Count, Name, BaseCode, BaseName, DealerCode, DealerName; added up per day, person, type and dealer).
- You can lock the menu for a person with **🔐 Menu access → 🎯 Target vs Collection** (see [[Admin Guide]]).

Related: [[Manager Guide]] · [[Admin Guide]] · [[Reports and Excel]]
