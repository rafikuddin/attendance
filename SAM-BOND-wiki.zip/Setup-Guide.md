# 🧰 Setup Guide

One-time setup for a new installation. You need a Google account, a GitHub account and an Android phone.

> [!IMPORTANT]
> **Never** put the signing key file, its passwords, or any password into the repository, the README or this wiki.

---

## 1️⃣ Google Sheet + Apps Script

1. Create a new **Google Sheet**.
2. **Extensions → Apps Script**, paste in `Code.gs`, **Save**.
3. If the script is **not** opened from inside the Sheet, set `SHEET_ID` at the top of `Code.gs` to the ID in the sheet's URL (the text between `/d/` and `/edit`).
4. Run the **`setup`** function once and approve the permission prompts. It creates the tabs:

| Tab | Purpose |
|---|---|
| **Users** | `Username · Password · Name · Manager · TokenEpoch · Role · MustChange · AppVersion · AppCode · LastSeen` |
| **Attendance** | Filled as staff check in |
| **Leaves** | Filled as staff apply; **Status** is set by a manager in the app |
| **NightHold**, **Notices**, **Holidays**, **Profiles**, **ManualEntry** | Created automatically on first use |

5. Add your staff to **Users**. **Manager** = another user's username (blank if none) — this builds the hierarchy. You may type a plain password for a new person; it is replaced by a secure hash on first sign-in, and they must choose a new one.
   - Leave **TokenEpoch**, **MustChange** and columns **H–J** alone — the script manages them.
6. **Make your first admin** — see [[Admin Guide]].
7. **Deploy → New deployment → Web app**
   - *Execute as*: **Me**
   - *Who has access*: **Anyone**
   - Copy the URL ending in **`/exec`**.

**Upgrading an old sheet?** Make a backup copy first, then run **`upgradeSecurity`** once (hashes every plain-text password and creates the token secret; safe to run again).

## 2️⃣ Connect the app

Open `app/src/main/java/com/example/attendance/Api.kt`, paste the `/exec` URL into `Config.SCRIPT_URL`, and commit.

> [!WARNING]
> Updates that you upload must **never overwrite** `Api.kt`'s script URL.

## 3️⃣ Signing key (one time)

Releases are signed with a private key that is **never** stored in the repo.

1. On a computer with Java, create the key. Keep the file and both passwords safe — **if you lose it, you can never update the app again** and everyone must uninstall and reinstall:
   ```
   keytool -genkeypair -v -keystore sambond-release.jks -alias sambond -keyalg RSA -keysize 2048 -validity 10000
   ```
2. Turn it into text:
   - Linux: `base64 -w0 sambond-release.jks`
   - macOS: `base64 -i sambond-release.jks | tr -d '\n'`
   - Windows PowerShell: `[Convert]::ToBase64String([IO.File]::ReadAllBytes("sambond-release.jks"))`
3. In GitHub: **Settings → Secrets and variables → Actions → New repository secret**. Add four secrets:

| Secret | Value |
|---|---|
| `KEYSTORE_BASE64` | The text from step 2 |
| `KEYSTORE_PASSWORD` | Keystore password |
| `KEY_ALIAS` | `sambond` (as above) |
| `KEY_PASSWORD` | Key password |

If the secrets are **missing** the build still runs with a throw-away key: the file is named `…-TEMP-KEY.apk` and can only be installed fresh. If a secret is wrong the build **fails with a clear message**.

## 4️⃣ Build the APK

- Push to the repo, or **Actions → Build APK → Run workflow**.
- Download from the run's **`app-release`** artifact or the **Releases** page (easiest on a phone).
- Install on an Android 7.0+ phone.

If the build fails, open the run's **Summary** — the *"Build failed – the real error"* box shows the exact line; the full log is a `build-log` artifact.

## 5️⃣ First-day checklist

- [ ] Users added and **Manager** column linked
- [ ] First admin works (Admin Panel visible)
- [ ] Sample rows (`manager1`, `demo`) deleted
- [ ] `securityCheck` run once
- [ ] Holidays added
- [ ] Night-hold hours set (Admin Panel → 📝 Entry)
- [ ] 2-Step Verification on the Google account that owns the Sheet
- [ ] Repo is **private**, or only trusted people have write access
- [ ] APK sent to staff

Next: [[Configuration]] · [[Updating the App]]
