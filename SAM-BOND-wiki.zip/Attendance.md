# 📸 Attendance

## Check in

1. Open **Attendance** (bottom bar).
2. Tap **📸 Capture Selfie** and take a clear photo of your face.
3. Wait for the location to lock (see tips below).
4. Check the date, time, coordinates and address, then tap **Submit**.
5. A **pop-up** tells you the result: **✅ Attendance submitted** (or **⏰ Late Present**) with the date and time, or **ℹ️ Already submitted** if today's attendance was already recorded. The pop-up closes by itself after **5 seconds** (or tap OK).

Once you have submitted (Present or Late), or the day is marked **Absent**, the camera, **Capture Selfie** and **Submit Attendance** are hidden — only the status card remains. A day an admin opened for you (manual entry) always shows the form.

At the top of this screen you always see **Today's Status** (the same card as on Home): your status, present/absent days of the 26th–25th, your selfie and the location. It updates right after you submit.

A selfie is **required** and so is a **real, live location**. The **date and time are stamped by Google's server**, so changing the phone's clock changes nothing.

## The rules

| Rule | What happens |
|---|---|
| **On time** | Submit up to **9:09 AM** |
| **⏰ Late Present** | From **9:10 AM** (10-minute grace period); the time is shown |
| **Absent** | Still not marked at **6:00 PM**; past unmarked days show as Absent |
| **Friday** | Automatic weekly off — never counted as absent |
| **Holiday** | Any holiday an admin adds behaves like Friday |
| **One per day** | A second check-in on the same day is blocked |
| **Leave conflict** | You cannot check in on an approved-leave day, and cannot apply for leave on a day you already checked in |
| **Out of area** | A location outside Bangladesh is refused by the server |
| **Fake GPS** | Mock locations are refused. Turn off any fake-GPS app |

After you check in, the **Today's Status** circle on Home shows your selfie (tap to enlarge) and where it was taken.

## 📍 Getting a GPS fix quickly

The app keeps listening until it has a good position and shows the seconds while it searches.

- Make sure **Location** is switched **ON** (quick settings) and set to **High accuracy** if your phone offers it.
- Indoors, step **next to a window** or outside for a moment.
- After **10 seconds** a slightly rougher fix is accepted so you are not stuck indoors.
- After **45 seconds** you see a message and a **Retake / Retry** button.
- Android battery savers can slow GPS. Allow the app to use location while it is open.

## Forgot to check in?

Ask an admin to open **manual entry** for that date — see [[Admin Guide]]. You will then see **📝 Manual entry** in your 👤 menu and can fill that day (selfie and GPS are still required, once per date). Those records are marked **[Manual]**.

Related: [[Leave]] · [[Night Hold]] · [[Troubleshooting]]

## 📝 Late reason
If your attendance is marked **⏰ Late Present**, a pop-up asks **why you were late** straight after you submit. **You must write the reason** (3–200 characters): the pop-up cannot be closed without it, and it comes back until you do. After that a line **📝 Add late reason** appears under *Today's status* (Home and the Attendance screen). Tap it, write why you were late (3–200 characters) and press OK. You can change the text the same day. Your line manager sees it on your card in **Team**, and managers and admins see it on that day in your **Calendar**. It is kept on the *LateReasons* tab of the Google Sheet.

## 🚗 Drivers: the car meter picture
If your admin gave you the **Driver** right, Attendance has **two steps**:

1. **Selfie** with the front camera (the live check works as usual).
2. As soon as the selfie is taken, the page scrolls down and the **back camera** opens in a second card. Hold the phone close to the **car meter** (the km counter) so the digits are sharp and fill the picture. Tap the picture to focus; tap **🔦** for light. Then tap **📷 Capture car meter**.

The phone now **reads the km number** from the picture. When it finds one you see **✅ Car meter verified · 123456 km** and the **Submit Attendance** button appears (it also waits for the location, as always). **Without a verified meter picture there is no Submit button.**

If you see **❌ No km number could be read**: tap **🔄 Retake car meter**, move closer, hold the phone steady, avoid the shine on the glass and use 🔦 in the dark. You can retake the meter picture as often as you like, and retaking the **selfie** does not throw the meter picture away.

Good to know:
- The meter picture is kept with your attendance. You see it on **Today's Status** (*🚗 Car meter · 123456 km · tap to see the picture*), and your line managers see it on your card in **Team**.
- If the phone cannot run the reader (no Google Play services model yet), the picture is accepted without a number.
- The app must be updated: an old app cannot take the meter picture, and the server then refuses a driver's attendance.
- Your admin can switch the **number reading** off if the meters cannot be read (Admin Guide → Entry); the picture itself is still required.

### 🏁 Day end (end of the work day)
When your work day is over, a driver also sends a **Day End**. It needs **no selfie and no location**, only a new picture of the car meter:

1. Open **Mark Attendance**. Once your attendance is marked, the page shows the **🏁 Day end** card.
2. Tap **📷 Start Day End**. The back camera opens. Hold the phone close to the car meter, tap the picture to focus (🔦 for light) and tap **📷 Capture car meter**.
3. The phone reads the km number exactly as in the morning (**✅ Car meter verified · 123789 km**, and how many km the car went since this morning's picture). When it finds a number the **🏁 Submit Day End** button appears. **Without a verified meter picture there is no Submit Day End button.** If you see ❌ *No km number could be read*, use **🔄 Retake car meter**.
4. Tap **🏁 Submit Day End**. You see *🏁 Day end submitted* with the time and **Driven today: N km** (the day end km minus this morning's km).

Good to know:
- Only for drivers, only **after** today's attendance is marked, and only **once a day**. It must be sent on **the same date as the attendance** (before midnight): after midnight the date has changed and there is no attendance for the new date.
- *Today's status* (Attendance and Home) then shows **🏁 Day end · time · km · N km driven · tap to see the picture**. Until the day end is sent, Home shows *🏁 Day end not sent yet* as a reminder. Your line managers see the same line on your card in **Team** (*🏁 Day end · not yet* until it is sent).
- The distance is worked out from the two km numbers. If one of them could not be read, or the day end number is lower than the morning one, no distance is shown (the pictures are still saved). When your new number is lower than this morning's, the phone warns you under the picture, so a misread number can be retaken.
- The app must be updated: an old app has no Day End step.
- The admin's **number reading** switch (Admin Guide → Entry) applies to the day end picture too.

## 👁 Live check (before the selfie)
The **📸 Capture Selfie** button is hidden at first. Look at the front camera: the screen asks you to do **two quick things** (*blink*, *turn your head to one side* or *smile*, picked at random). When you have done them the button appears and you have 30 seconds to use it. This shows a real person is there, not a photo. Nothing leaves the phone for this check. If your phone cannot do it, the button simply shows. **Your admin can switch this check off** (Admin Guide → Entry); then the button shows as soon as the camera opens.

The phone turns your selfie into a short code (a face print) and sends only that code with your attendance. Your first selfies become your reference; every later selfie is compared with it. If it does not look like you, **your attendance is still saved** and your line manager and the admin see a note. If the note is wrong (new glasses, beard, a dark room), nothing happens to you: just take the next selfie in good light. Ask the admin to **Reset face** if your first selfie was bad.
