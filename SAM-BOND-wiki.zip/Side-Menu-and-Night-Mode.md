# 🌙 Side Menu and Day / Night Mode

## The side menu
Tap the **👤** button at the top right of Home. A panel slides in from the right edge of the screen:

- **🔍 Search** – type a few letters to find a menu quickly.
- **Menu** – Home, Attendance, Leave, Night Hold, Calendar, Team (managers only), Notices (with the unread count), My Reports, Target vs Collection. A **🔒** means an admin has locked that menu for you.
- **Settings** – My Profile, Change Password, Attendance reminders (On/Off), *Manual entry* and *Update app* when they are available, and **Admin Panel** for admins.
- **☀️ Light / 🌙 Dark** – the colour switch (below).
- **Your name** at the bottom with a red **⎋** button to **log out** (it asks to confirm).
- The round **›** button folds the panel into a slim strip of icons. Tap **‹** (or the 🔍) to open it again. The app remembers your choice.

Tap outside the panel to close it.

## Day / Night colours
The app uses two colours: **Clay Brown** `#6B352A` (headers, buttons, text) and **Soft Butter** `#FFF1A6` (backgrounds, chips, highlights). Light mode is clay text on warm cream; Dark mode is butter text on deep clay, and the main buttons turn butter with clay text. Red, green and amber keep their meaning (late, absent, approved, warnings) in both modes.

Choose **☀️ Light** or **🌙 Dark** in the side menu. The **whole app** changes at once (every screen, the dialogs, the bottom bar and the Admin Panel). The choice is kept on **your phone** only, so every person can pick their own. The default is Light.

## For admins
Nothing to set up on the server. Update the app (see [[Updating the App]]) and the new menu and colours appear.

## Password and search boxes

- **Password fields** are labelled fields: the label sits in the box, then lifts into the top edge when you tap it, with a show/hide eye. They look the same on the sign-in page, create account, forgot / change password and the admin password confirmations, in Light and Dark.
- **Search** (side menu, Admin → Users, My Team, pick lists) is a search icon that opens into the field when you tap it. Tap **✕** to clear; with an empty box it folds back into the icon.
