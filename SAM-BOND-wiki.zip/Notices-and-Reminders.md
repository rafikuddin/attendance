# 🔔 Notices and Reminders

## 🔔 Notification sound
Reminders in the notification bar now play the app's own short **ding-ding** chime and vibrate twice. The same chime sounds inside the app when a new notice arrives. It follows your phone's notification volume: on silent or vibrate mode it stays quiet. To change or turn off the sound, open **Phone Settings → Apps → SAM BOND → Notifications → Attendance reminders** (Android 8 and newer).

## 📢 Notices

Two kinds of notice exist:

| Kind | Who posts | Who sees it |
|---|---|---|
| 📢 **Admin notice** | An admin (Admin Panel → Notices) | **Everyone** |
| 👥 **Team notice** | A **manager** (Notices screen → **✍️ Post a notice**) | The manager **and everyone below them** — not their own boss, not other teams |

Ordinary staff cannot post. Only the manager who wrote a team notice can remove it (🗑 on the notice).

A manager posts a title, a message and how many days it stays (7 by default, up to 90). Team notices are labelled **👥 team notice**.

- A card appears on **Home**.
- A 🔔 **bell** at the top shows a red number for notices you have not opened.
- A **pop-up** appears on Home every time you sign in or open the app fresh. **Got it** closes it; **View all notices** opens the full list.
- Notices stay for **7 days** by default (up to 90).

> [!NOTE]
> The notice pop-up is shown **by the app when it is open**. It is not a phone push notification (no banner or sound while the app is closed).

## ⏰ Attendance reminders (notification bar)

If you have not marked attendance, your phone shows a notification.

| Time (working days) | You see |
|---|---|
| From **8:30 AM** | *Mark your attendance* |
| From **9:10 AM** | *You have not marked attendance* |
| **Managers**, from 9:10 AM | *👥 N team members not marked yet* with the names |

- Tap the notification to open the attendance screen.
- It **disappears** once you have marked attendance.
- It **never appears** on Friday, on a holiday, or during approved leave.
- At most **one reminder of each kind per hour**. They stop at 6:00 PM.
- Switch them off: **👤 menu → Attendance reminders**.
- Android 13+ asks for notification permission the first time.

### How reliable are they?

The phone checks about **every 30 minutes** (Android chooses the exact moment to save battery). They are **not instant push messages**. Phones with an aggressive battery saver (Xiaomi, Oppo, Vivo, some Samsung) may delay them.

> [!TIP]
> Settings → Apps → SAM BOND Attendance → Battery → **Unrestricted** gives the most punctual reminders.

Real instant push would need Firebase, which the project does not use.

Related: [[Attendance]] · [[Troubleshooting]]

## 📱 Also as an SMS

When posting a notice, admins can tick **Also send as an SMS to everyone's phone**, and managers **Also send as an SMS to my team**. People get a real text on the phone number in their profile, even if the app is closed. Needs the one-time SimGate setup on [[SMS Notifications]].
