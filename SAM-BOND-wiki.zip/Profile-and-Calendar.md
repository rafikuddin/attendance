# 👤 Profile and 📅 Calendar

## My Profile

Open it from the **round photo at the top-left of Home**, or **👤 menu → My Profile**.

| Field | Notes |
|---|---|
| **Profile photo** | 📷 *Take photo* or 🖼 *Choose picture*. Separate from your daily selfie; replaces the letter in the round avatar |
| **Official phone**, **Personal phone** | Digits, 8–15 long, optional `+` |
| **Email** | Checked for a valid format |
| **Emergency contact** | Phone number **plus relation** (a phone and its relation go together) |
| **Relation** | Wife, Son, Brother, Mother, Father, Daughter, **Other** (then type your own) |
| **Bike number** | Optional |
| **Base Name** | Pick from a searchable list; the **Base Code** fills in by itself. The list is the **Bases** tab of the Sheet (BaseCode, BaseName): edit it to add, rename or remove bases. |
| **T-shirt size** | S, M, L, XL, XXL or 2XL |
| **Laptop model** | **Managers only** |

Every field is optional. **Only you** (or an admin) can change your profile. Your profile photo is visible to you, the supervisors above you and admins.

## Calendar

The **Calendar** shows the pay period (**26th → 25th**) at a glance, with a different colour for each kind of day:

| Day | Meaning |
|---|---|
| Present | Attendance marked on time |
| Late | Marked from 9:10 AM |
| Leave | Approved leave |
| Friday off | Weekly off |
| 🎉 Holiday | A holiday an admin added (the name is shown) |
| Absent | Nothing marked by 6:00 PM |
| 🌙 Night hold | A night hold was submitted |

Tap any date for details, including that day's night-hold status.

Related: [[Attendance]] · [[Leave]] · [[Night Hold]]
