package com.example.attendance

import android.Manifest
import android.annotation.SuppressLint
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Matrix
import android.location.Geocoder
import android.location.Location
import android.media.ExifInterface
import android.os.Bundle
import android.util.Base64
import android.view.View
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.camera.core.*
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import com.google.android.material.card.MaterialCardView
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.File
import java.text.SimpleDateFormat
import java.util.*

class AttendanceActivity : AppCompatActivity() {
    private lateinit var session: Session
    private lateinit var previewView: PreviewView
    private lateinit var imgSelfie: ImageView
    private lateinit var tvLive: TextView
    private lateinit var tvSummary: TextView
    private lateinit var cardSummary: MaterialCardView
    private lateinit var btnCapture: Button
    private lateinit var btnSubmit: Button

    private var imageCapture: ImageCapture? = null
    private var photoFile: File? = null
    private var captureTime: Date? = null
    private var location: Location? = null
    private var address: String = "Address unavailable"
    private var forDate: String? = null          // set when an admin opened a past day for this person (manual entry)

    private val dateFmt = SimpleDateFormat("dd MMM yyyy", Locale.getDefault())
    private val timeFmt = SimpleDateFormat("hh:mm:ss a", Locale.getDefault())

    private val permLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { if (it.values.all { granted -> granted }) startCamera()
        else toast("Camera & location permissions are required") }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        session = Session(this)
        if (!session.loggedIn) { goLogin(); return }
        setContentView(R.layout.activity_attendance)
        previewView = findViewById(R.id.previewView)
        imgSelfie = findViewById(R.id.imgSelfie)
        tvLive = findViewById(R.id.tvLive)
        tvSummary = findViewById(R.id.tvSummary)
        cardSummary = findViewById(R.id.cardSummary)
        forDate = intent.getStringExtra(EXTRA_FOR_DATE)?.takeIf { it.isNotBlank() }
        setupHeader(if (forDate != null) "Manual Attendance" else "Mark Attendance")
        setupBottomNav(Tab.ATTENDANCE)
        enforceAccess("attendance")
        btnCapture = findViewById(R.id.btnCapture)
        btnSubmit = findViewById(R.id.btnSubmit)

        btnCapture.setOnClickListener {
            if (photoFile != null) retake() else captureSelfie()
        }
        btnSubmit.setOnClickListener { submit() }

        forDate?.let { d ->
            cardSummary.visibility = View.VISIBLE
            cardSummary.setCardBackgroundColor(Pal.c("#EEF2FF"))
            tvSummary.setTextColor(Pal.c("#3730A3"))
            tvSummary.text = "📝 Manual attendance for $d\nAn admin opened this day for you. Take your selfie as usual."
        }
        val perms = arrayOf(Manifest.permission.CAMERA, Manifest.permission.ACCESS_FINE_LOCATION)
        if (perms.all { ContextCompat.checkSelfPermission(this, it) == PackageManager.PERMISSION_GRANTED })
            startCamera() else permLauncher.launch(perms)
    }

    private fun goLogin() {
        startActivity(Intent(this, LoginActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK))
        finish()
    }

    private fun startCamera() {
        val future = ProcessCameraProvider.getInstance(this)
        future.addListener({
            val provider = future.get()
            val preview = Preview.Builder().build().also { it.setSurfaceProvider(previewView.surfaceProvider) }
            imageCapture = ImageCapture.Builder().build()
            val selector = if (provider.hasCamera(CameraSelector.DEFAULT_FRONT_CAMERA))
                CameraSelector.DEFAULT_FRONT_CAMERA else CameraSelector.DEFAULT_BACK_CAMERA
            provider.unbindAll()
            provider.bindToLifecycle(this, selector, preview, imageCapture)
        }, ContextCompat.getMainExecutor(this))
    }

    private fun captureSelfie() {
        val capture = imageCapture ?: return
        btnCapture.isEnabled = false
        captureTime = Date()
        val file = File(cacheDir, "selfie_${System.currentTimeMillis()}.jpg")
        capture.takePicture(ImageCapture.OutputFileOptions.Builder(file).build(),
            ContextCompat.getMainExecutor(this),
            object : ImageCapture.OnImageSavedCallback {
                override fun onImageSaved(r: ImageCapture.OutputFileResults) {
                    photoFile = file
                    btnCapture.text = "🔄  Retake"
                    btnCapture.isEnabled = true
                    fetchLocation()                       // starts right away, in parallel with the preview below
                    Thread {
                        val preview = try { loadScaled(file.absolutePath, 800) } catch (e: Exception) { null }
                        runOnUiThread {
                            if (preview != null && photoFile == file) {
                                imgSelfie.setImageBitmap(preview)
                                imgSelfie.visibility = View.VISIBLE
                            }
                        }
                    }.start()
                }
                override fun onError(e: ImageCaptureException) {
                    btnCapture.isEnabled = true
                    toast("Capture failed: ${e.message}")
                }
            })
    }

    /** Loads a photo, applies EXIF rotation and shrinks it so uploads stay small. */
    private fun loadScaled(path: String, max: Int): Bitmap {
        val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(path, o)
        var s = 1
        while (o.outWidth / s > max * 2 || o.outHeight / s > max * 2) s *= 2
        val bmp = BitmapFactory.decodeFile(path, BitmapFactory.Options().apply { inSampleSize = s })
        val deg = when (ExifInterface(path).getAttributeInt(ExifInterface.TAG_ORIENTATION, 1)) {
            ExifInterface.ORIENTATION_ROTATE_90 -> 90
            ExifInterface.ORIENTATION_ROTATE_180 -> 180
            ExifInterface.ORIENTATION_ROTATE_270 -> 270
            else -> 0
        }
        val m = Matrix()
        if (deg != 0) m.postRotate(deg.toFloat())
        val sc = minOf(1f, max.toFloat() / maxOf(bmp.width, bmp.height))
        m.postScale(sc, sc)
        return Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, m, true)
    }

    private fun retake() {
        photoFile = null
        imgSelfie.visibility = View.GONE
        btnCapture.text = "📸  Capture Selfie"
        btnSubmit.isEnabled = false
        if (forDate == null) cardSummary.visibility = View.GONE
        tvLive.text = "Date: -\nTime: -\nLocation: -"
        locHandle?.cancel()
        location = null
    }

    private var locHandle: LiveLocation.Handle? = null

    override fun onDestroy() {
        locHandle?.cancel()
        super.onDestroy()
    }

    private fun fetchLocation() {
        locHandle?.cancel()
        location = null
        tvLive.text = "Getting location..."
        locHandle = LiveLocation.start(
            this,
            onProgress = { sec -> if (location == null) tvLive.text = LiveLocation.waitingText(sec) },
            onFail = { tvLive.text = "⚠️ $it\nThen tap Retake and capture again." },
            onFix = { loc ->
                if (isMockLocation(loc)) {
                    tvLive.text = "⚠️ A fake / mock location was detected. Turn off any fake-GPS app, then tap Retake and capture again."
                } else {
                    location = loc
                    Thread {
                        address = try {
                            @Suppress("DEPRECATION")
                            Geocoder(this, Locale.getDefault()).getFromLocation(loc.latitude, loc.longitude, 1)
                                ?.firstOrNull()?.getAddressLine(0) ?: "Address unavailable"
                        } catch (e: Exception) { "Address unavailable" }
                        runOnUiThread { if (location === loc) { showLive(); btnSubmit.isEnabled = true } }
                    }.start()
                }
            }
        )
    }

    private fun showLive() {
        val t = captureTime ?: return
        val l = location ?: return
        tvLive.text = "Date: ${dateFmt.format(t)}\nTime: ${timeFmt.format(t)}\n" +
            "Location: ${String.format(Locale.US, "%.5f, %.5f", l.latitude, l.longitude)}\n$address"
    }

    private fun submit() {
        val t = captureTime ?: return
        val l = location ?: return
        val file = photoFile ?: return

        btnSubmit.isEnabled = false
        btnCapture.isEnabled = false
        cardSummary.visibility = View.VISIBLE
        cardSummary.setCardBackgroundColor(Pal.c("#E3F2FD"))
        tvSummary.setTextColor(Pal.c("#0D47A1"))
        tvSummary.text = "Submitting..."

        val selfieTimeText = "${dateFmt.format(t)} ${timeFmt.format(t)}"
        val username = session.username
        val addr = address

        // Shrinking and encoding the photo is heavy, so it runs off the screen thread (no freezing).
        // 640px at quality 65 is plenty to recognise a face and uploads much faster on slow mobile data.
        Thread {
            val body: JSONObject = try {
                val out = ByteArrayOutputStream()
                loadScaled(file.absolutePath, 640).compress(Bitmap.CompressFormat.JPEG, 65, out)
                val photo = Base64.encodeToString(out.toByteArray(), Base64.NO_WRAP)
                JSONObject()
                    .put("action", "submit")
                    .put("username", username)
                    .put("selfieTime", selfieTimeText)
                    .put("lat", l.latitude).put("lng", l.longitude).put("mock", isMockLocation(l))
                    .put("address", addr)
                    .put("photo", photo)
                    .also { if (forDate != null) it.put("forDate", forDate) }
            } catch (e: Exception) {
                runOnUiThread {
                    btnSubmit.isEnabled = true; btnCapture.isEnabled = true
                    cardSummary.setCardBackgroundColor(Pal.c("#FFEBEE"))
                    tvSummary.setTextColor(Pal.c("#B71C1C"))
                    tvSummary.text = "❌ Couldn't prepare the photo. Please retake the selfie."
                }
                return@Thread
            }
            runOnUiThread { sendAttendance(body, t, l) }
        }.start()
    }

    private fun sendAttendance(body: JSONObject, t: Date, l: Location) {
        api(body) { res, err ->
            btnCapture.isEnabled = true
            if (res != null) {
                // Saved copies of Home and Calendar are now out of date.
                ResponseCache.remove(this, ResponseCache.homeKey(session.username), ResponseCache.calKey(session.username))
                Reminders.clearSelf(this)   // the "mark your attendance" reminder is no longer needed
                photoFile?.delete()   // the selfie now lives on the server; don't keep a copy on the phone
                val late = res.optBoolean("late")
                cardSummary.setCardBackgroundColor(Pal.c(if (late) "#FFEDD5" else "#DCFCE7"))
                tvSummary.setTextColor(Pal.c(if (late) "#9A3412" else "#166534"))
                tvSummary.text = "${if (late) "⏰ Late Present" else "✅ Attendance Submitted"}${if (res.optBoolean("manual")) " (manual)" else ""}\n\nDate: ${res.optString("date")}\nTime: ${res.optString("time")}\n" +
                    "Selfie time: ${dateFmt.format(t)} ${timeFmt.format(t)}\n" +
                    "Location: ${String.format(Locale.US, "%.5f, %.5f", l.latitude, l.longitude)}\n$address"
                popup(if (late) "⏰ Late Present" else "✅ Attendance submitted",
                    (if (late) "Your attendance was recorded as late.\n\n" else "Your attendance was submitted successfully.\n\n") +
                    "Date: ${res.optString("date")}\nTime: ${res.optString("time")}")
            } else {
                val already = err?.contains("already", ignoreCase = true) == true
                btnSubmit.isEnabled = !already          // a second submit for the same day can never work
                cardSummary.setCardBackgroundColor(Pal.c(if (already) "#E3F2FD" else "#FFEBEE"))
                tvSummary.setTextColor(Pal.c(if (already) "#0D47A1" else "#B71C1C"))
                tvSummary.text = if (already) "ℹ️ $err" else "❌ $err"
                if (already) popup("ℹ️ Already submitted", err ?: "Your attendance for today is already submitted.")
            }
        }
    }

    private fun toast(m: String) = Toast.makeText(this, m, Toast.LENGTH_SHORT).show()

    /** A small pop-up after submitting: success, or "already submitted". */
    private fun popup(title: String, message: String) {
        if (isFinishing || isDestroyed) return
        androidx.appcompat.app.AlertDialog.Builder(this).setTitle(title).setMessage(message)
            .setPositiveButton("OK", null).show()
    }
}
